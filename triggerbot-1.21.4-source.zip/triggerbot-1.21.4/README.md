# TriggerBot — Minecraft 1.21.4 Fabric

Client-side Fabric mod.

## Behavior

- Toggle: `0` key.
- Disabled by default.
- Sends `Триггербот включен` / `Триггербот выключен` in chat when toggled.
- Detects the start of a jump.
- During the falling phase, if the crosshair is on an attackable living entity and the attack cooldown is ready, performs one attack.
- The attack is timed for the normal vanilla critical-hit window.
- Only one automatic attack is performed per jump.

## Requirements

- Minecraft Java Edition 1.21.4
- Fabric Loader 0.16.14 or newer compatible with 1.21.4
- Fabric API for 1.21.4
- Java 21

## Build

From this directory:

```bash
./gradlew build
```

The resulting jar is under `build/libs/`.

The project was prepared against Minecraft 1.21.4, Yarn 1.21.4+build.7, Fabric Loader 0.16.14, and Fabric API 0.119.0+1.21.4.
