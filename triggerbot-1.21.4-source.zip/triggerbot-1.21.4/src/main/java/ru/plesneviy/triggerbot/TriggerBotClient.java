package ru.plesneviy.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public final class TriggerBotClient implements ClientModInitializer {
    private static boolean enabled = false;
    private static boolean jumpStarted = false;
    private static boolean attackedThisJump = false;

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_0,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(TriggerBotClient::tick);
    }

    private static void tick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            jumpStarted = false;
            attackedThisJump = false;

            if (client.player != null) {
                client.player.sendMessage(
                        Text.literal(enabled ? "Триггербот включен" : "Триггербот выключен"),
                        false
                );
            }
        }

        if (!enabled || client.player == null || client.interactionManager == null || client.world == null) {
            return;
        }

        PlayerEntity player = client.player;

        // Arm once the player actually starts a jump.
        if (!player.isOnGround() && player.getVelocity().y > 0.05) {
            jumpStarted = true;
            attackedThisJump = false;
        }

        // Only attack during the falling part of a jump, which is the normal
        // timing window for a vanilla critical hit.
        boolean falling = player.getVelocity().y < -0.02;
        boolean criticalWindow = !player.isOnGround()
                && player.fallDistance > 0.0f
                && falling
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.hasVehicle()
                && !player.isGliding();

        if (jumpStarted && !attackedThisJump && criticalWindow
                && player.getAttackCooldownProgress(0.0f) >= 1.0f
                && client.crosshairTarget instanceof EntityHitResult hit) {

            Entity target = hit.getEntity();
            if (target != player && target.isAttackable() && target.isAlive()) {
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                attackedThisJump = true;
            }
        }

        // A new jump can only arm after landing.
        if (player.isOnGround()) {
            jumpStarted = false;
            attackedThisJump = false;
        }
    }
}
