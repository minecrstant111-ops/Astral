package dev.astral.gui;
import java.util.*;
import java.util.function.*;
import dev.astral.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class ClickGui extends Screen {
  static final int PW = 132, RH = 16, ACC = 0xFF7C5CFF, ACC2 = 0xFF4CC9F0, TXT = 0xFFB8B8D0;
  static final class Hit { final int x, y, w, h; final IntConsumer click; final DoubleConsumer drag;
    Hit(int x, int y, int w, int h, IntConsumer c, DoubleConsumer d){ this.x = x; this.y = y; this.w = w; this.h = h; click = c; drag = d; }
    boolean in(double mx, double my){ return mx >= x && mx < x + w && my >= y && my < y + h; } }
  final List<Hit> hits = new ArrayList<>(); Hit active; Module dragMod; Setting typing;
  final float[] scroll = new float[3], maxScroll = new float[3]; int visTop, visBot;
  public ClickGui(){ super(Text.literal("Astral")); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void removed(){ Config.save(); }
  void hit(int x, int y, int w, int h, IntConsumer c, DoubleConsumer d){ if (y + h > visTop && y < visBot) hits.add(new Hit(x, y, w, h, c, d)); }

  @Override public void render(DrawContext c, int mx, int my, float td){
    c.fill(0, 0, width, height, 0x77000000); hits.clear();
    visTop = 0; visBot = height;
    for (Module m : Astral.MODULES) if (m.on && m.movable) {
      c.drawBorder(m.x - 2, m.y - 2, m.w + 4, m.h + 4, 0x887C5CFF);
      final Module mm = m; hit(m.x - 2, m.y - 2, m.w + 4, m.h + 4, b -> dragMod = mm, null);
    }
    int x0 = width / 2 - (3 * PW + 24) / 2, py = 30; Module.Cat[] cats = Module.Cat.values();
    c.drawText(textRenderer, "Astral", x0, 14, ACC, true); c.drawText(textRenderer, "  |  RShift - close", x0 + textRenderer.getWidth("Astral"), 14, 0xFF77778A, false);
    for (int i = 0; i < cats.length; i++) panel(c, cats[i], x0 + i * (PW + 12), py, mx, my, i);
  }

  void panel(DrawContext c, Module.Cat cat, int px, int py, int mx, int my, int idx){
    int ph = Math.min(height - py - 16, 420);
    RenderUtil.rrect(c, px, py, PW, ph, 7, 0xEE12121C); RenderUtil.rrect(c, px, py, PW, 20, 7, 0xFF2A2250);
    c.drawText(textRenderer, cat.label, px + 8, py + 6, 0xFFFFFFFF, false);
    int top = py + 22; visTop = top; visBot = py + ph - 2; c.enableScissor(px, top, px + PW, visBot);
    int y = top + (int) scroll[idx];
    for (Module m : Astral.MODULES) {
      if (m.cat != cat) continue;
      boolean hov = mx >= px + 3 && mx < px + PW - 3 && my >= y && my < y + RH - 1 && my >= top && my < visBot;
      RenderUtil.rrect(c, px + 3, y, PW - 6, RH - 1, 4, m.on ? 0xFF5B44C9 : hov ? 0xFF232336 : 0xFF181826);
      c.drawText(textRenderer, m.name, px + 8, y + 4, m.on ? 0xFFFFFFFF : TXT, false);
      if (!m.settings.isEmpty()) c.drawText(textRenderer, m.open ? "v" : ">", px + PW - 14, y + 4, 0xFF9A9AB5, false);
      final Module mm = m; hit(px + 3, y, PW - 6, RH - 1, b -> { if (b == 0) mm.toggle(); else if (b == 1) mm.open = !mm.open; }, null);
      y += RH;
      if (m.open) for (Setting s : m.settings) y += setting(c, s, px + 7, y, PW - 14);
    }
    maxScroll[idx] = Math.max(0, (y - (int) scroll[idx]) - top - (ph - 26));
    c.disableScissor();
  }

  static String fmt(double v){ return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.2f", v); }

  int setting(DrawContext c, Setting s, int x, int y, int w){
    var tr = textRenderer;
    switch (s.type) {
      case BOOL -> { c.drawText(tr, s.name, x + 2, y + 3, TXT, false); int tx = x + w - 22;
        RenderUtil.rrect(c, tx, y + 2, 20, 10, 5, s.b ? ACC : 0xFF2B2B42); RenderUtil.rrect(c, tx + (s.b ? 11 : 1), y + 3, 8, 8, 4, 0xFFFFFFFF);
        hit(x, y, w, 14, b -> s.b = !s.b, null); return 15; }
      case NUM -> { c.drawText(tr, s.name, x + 2, y + 1, TXT, false); String v = fmt(s.n); c.drawText(tr, v, x + w - 2 - tr.getWidth(v), y + 1, 0xFFFFFFFF, false);
        RenderUtil.rrect(c, x + 2, y + 12, w - 4, 4, 2, 0xFF2B2B42); int fw = (int) ((s.n - s.min) / (s.max - s.min) * (w - 4)); RenderUtil.rrect(c, x + 2, y + 12, Math.max(fw, 4), 4, 2, ACC2);
        final int bx = x + 2, bw = w - 4;
        hit(x, y, w, 20, null, mxx -> { double p = MathHelper.clamp((mxx - bx) / bw, 0, 1); s.n = Math.round((s.min + p * (s.max - s.min)) * 100) / 100.0; }); return 21; }
      case MODE -> { c.drawText(tr, s.name, x + 2, y + 3, TXT, false); String v = "< " + s.modeName() + " >"; c.drawText(tr, v, x + w - 2 - tr.getWidth(v), y + 3, 0xFFFFFFFF, false);
        hit(x, y, w, 14, b -> s.mode = Math.floorMod(s.mode + (b == 0 ? 1 : -1), s.modes.length), null); return 15; }
      case COLOR -> { c.drawText(tr, s.name, x + 2, y + 1, TXT, false); int sw = w - 4;
        for (int i = 0; i < sw; i += 2) c.fill(x + 2 + i, y + 12, x + 4 + i, y + 17, 0xFF000000 | MathHelper.hsvToRgb(i / (float) sw, 0.65f, 1f));
        int mk = x + 2 + (int) (s.n * sw); c.fill(mk - 1, y + 10, mk + 1, y + 19, 0xFFFFFFFF); final int bx = x + 2;
        hit(x, y, w, 20, null, mxx -> s.n = MathHelper.clamp((mxx - bx) / sw, 0, 1)); return 21; }
      default -> { c.drawText(tr, s.name, x + 2, y + 1, TXT, false); boolean ty = typing == s;
        RenderUtil.rrect(c, x + 2, y + 11, w - 4, 12, 3, ty ? 0xFF2F2A55 : 0xFF1F1F30); c.drawText(tr, s.text + (ty && System.currentTimeMillis() / 400 % 2 == 0 ? "_" : ""), x + 5, y + 13, 0xFFFFFFFF, false);
        hit(x, y, w, 24, b -> typing = s, null); return 25; }
    }
  }

  @Override public boolean mouseClicked(double mx, double my, int button){
    typing = null;
    for (int i = hits.size() - 1; i >= 0; i--) { Hit h = hits.get(i); if (h.in(mx, my)) {
      if (h.click != null) h.click.accept(button); if (h.drag != null) { h.drag.accept(mx); active = h; } return true; } }
    return super.mouseClicked(mx, my, button);
  }
  @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy){
    if (active != null && active.drag != null) { active.drag.accept(mx); return true; }
    if (dragMod != null) { dragMod.x = MathHelper.clamp(dragMod.x + (int) Math.round(dx), 0, width - 10); dragMod.y = MathHelper.clamp(dragMod.y + (int) Math.round(dy), 0, height - 10); return true; }
    return false;
  }
  @Override public boolean mouseReleased(double mx, double my, int b){ active = null; dragMod = null; return super.mouseReleased(mx, my, b); }
  @Override public boolean mouseScrolled(double mx, double my, double hx, double vy){
    int x0 = width / 2 - (3 * PW + 24) / 2; int i = (int) ((mx - x0) / (PW + 12)); if (i < 0 || i > 2) return false;
    scroll[i] = MathHelper.clamp(scroll[i] + (float) vy * 16, -maxScroll[i], 0); return true;
  }
  @Override public boolean keyPressed(int key, int sc, int mod){
    if (typing != null) { if (key == GLFW.GLFW_KEY_BACKSPACE && !typing.text.isEmpty()) typing.text = typing.text.substring(0, typing.text.length() - 1);
      else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) typing = null; return true; }
    if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
    return super.keyPressed(key, sc, mod);
  }
  @Override public boolean charTyped(char ch, int mod){ if (typing != null && typing.text.length() < 16 && ch >= 32) { typing.text += ch; return true; } return false; }
}
