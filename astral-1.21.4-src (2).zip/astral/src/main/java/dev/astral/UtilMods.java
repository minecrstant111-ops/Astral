package dev.astral;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import dev.astral.mixin.HandledScreenAccessor;
import org.lwjgl.glfw.GLFW;

public final class UtilMods {
  private UtilMods(){}
  public static class AutoSprint extends Module {
    public AutoSprint(){ super("Auto Sprint", Cat.UTILITY); }
    @Override public void tick(){
      var p = mc.player; if (p == null) return;
      if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision && !p.isUsingItem() && p.getHungerManager().getFoodLevel() > 6) p.setSprinting(true);
    }
  }
  public static class AutoRespawn extends Module {
    public AutoRespawn(){ super("Auto Respawn", Cat.UTILITY); }
    @Override public void tick(){ if (mc.player != null && mc.currentScreen instanceof DeathScreen) { mc.player.requestRespawn(); mc.setScreen(null); } }
  }
  public static class ItemScroller extends Module {
    final Setting delay = add(Setting.num("Delay (ms)", 30, 0, 200));
    static int lastId = -1; static long lastT;
    public ItemScroller(){ super("Item Scroller", Cat.UTILITY); }
    public static void scroll(HandledScreen<?> hs){
      ItemScroller m = Astral.get(ItemScroller.class); if (m == null || !m.on || mc.player == null || mc.interactionManager == null) return;
      long win = mc.getWindow().getHandle();
      boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT) == 1 || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == 1;
      if (!shift || GLFW.glfwGetMouseButton(win, 0) != 1) { lastId = -1; return; }
      Slot s = ((HandledScreenAccessor) hs).astral$getFocusedSlot(); if (s == null || !s.hasStack()) return;
      long now = System.currentTimeMillis(); if (s.id == lastId && now - lastT < 150 || now - lastT < m.delay.n) return;
      mc.interactionManager.clickSlot(hs.getScreenHandler().syncId, s.id, 0, SlotActionType.QUICK_MOVE, mc.player); lastId = s.id; lastT = now;
    }
  }
}
