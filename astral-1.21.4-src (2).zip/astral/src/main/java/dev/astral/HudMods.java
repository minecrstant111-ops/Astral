package dev.astral;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import dev.astral.gui.ClickGui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;

public final class HudMods {
  private HudMods(){}
  static final int BG = 0xD014141F, ACC = 0xFF7C5CFF, WHITE = 0xFFFFFFFF, GRAY = 0xFF8A8AA3;

  // ---- HUD watermark: Astral | fps | ping | time ----
  public static class Hud extends Module {
    final Setting fps = add(Setting.bool("FPS", true)), ping = add(Setting.bool("Ping", true)), time = add(Setting.bool("Time", true)), coords = add(Setting.bool("Coords", false));
    static final DateTimeFormatter F = DateTimeFormatter.ofPattern("HH:mm");
    public Hud(){ super("HUD", Cat.HUD); at(6, 6); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; var tr = mc.textRenderer; List<String> parts = new ArrayList<>();
      if (fps.b) parts.add(mc.getCurrentFps() + " fps");
      if (ping.b) { PlayerListEntry e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()); parts.add((e == null ? 0 : e.getLatency()) + " ms"); }
      if (time.b) parts.add(LocalTime.now().format(F));
      if (coords.b) parts.add((int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ());
      int tw = tr.getWidth("Astral"); for (String p : parts) tw += tr.getWidth(" | ") + tr.getWidth(p);
      w = tw + 14; h = 18; RenderUtil.rrect(c, x, y, w, h, 5, BG);
      int cx = x + 7, cy = y + 5; c.drawText(tr, "Astral", cx, cy, ACC, false); cx += tr.getWidth("Astral");
      for (String p : parts) { c.drawText(tr, " | ", cx, cy, 0xFF55556A, false); cx += tr.getWidth(" | "); c.drawText(tr, p, cx, cy, WHITE, false); cx += tr.getWidth(p); }
    }
  }

  // ---- Armor HUD: right of hotbar, durability % ----
  public static class ArmorHud extends Module {
    static final EquipmentSlot[] S = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    public ArmorHud(){ super("Armor HUD", Cat.HUD); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; var tr = mc.textRenderer;
      int bx = c.getScaledWindowWidth() / 2 + 98, by = c.getScaledWindowHeight() - 40;
      RenderUtil.rrect(c, bx - 3, by - 3, 4 * 20 + 3, 34, 5, BG);
      for (int i = 0; i < 4; i++) {
        ItemStack s = mc.player.getEquippedStack(S[i]); int ix = bx + i * 20; if (s.isEmpty()) continue;
        c.drawItem(s, ix, by);
        if (s.isDamageable()) { int pct = 100 - s.getDamage() * 100 / s.getMaxDamage(); String t = pct + "%"; int col = 0xFF000000 | MathHelper.hsvToRgb(pct / 300f, 0.7f, 1f);
          c.getMatrices().push(); c.getMatrices().translate(ix + 8 - tr.getWidth(t) * 0.35f, by + 19, 0); c.getMatrices().scale(0.7f, 0.7f, 1); c.drawText(tr, t, 0, 0, col, true); c.getMatrices().pop(); }
      }
    }
  }

  // ---- Cooldowns HUD ----
  public static class CooldownsHud extends Module {
    static final Item[] ITEMS = { Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.SHIELD, Items.WIND_CHARGE, Items.TRIDENT, Items.CROSSBOW, Items.FIREWORK_ROCKET, Items.SNOWBALL };
    public CooldownsHud(){ super("Cooldowns HUD", Cat.HUD); at(6, 70); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; var tr = mc.textRenderer; List<Object[]> rows = new ArrayList<>();
      for (Item it : ITEMS) { ItemStack st = new ItemStack(it); float p = mc.player.getItemCooldownManager().getCooldownProgress(st, td); if (p > 0) rows.add(new Object[]{ st, p }); }
      if (rows.isEmpty() && mc.currentScreen instanceof ClickGui) rows.add(new Object[]{ new ItemStack(Items.ENDER_PEARL), 0.65f });
      w = 96; h = rows.isEmpty() ? 0 : rows.size() * 19 + 3; if (rows.isEmpty()) return;
      RenderUtil.rrect(c, x, y, w, h, 5, BG); int yy = y + 3;
      for (Object[] r : rows) { float p = (float) r[1]; c.drawItem((ItemStack) r[0], x + 3, yy);
        RenderUtil.rrect(c, x + 24, yy + 10, 50, 4, 2, 0xFF2B2B42); RenderUtil.rrect(c, x + 24, yy + 10, Math.max(4, (int) (50 * (1 - p))), 4, 2, 0xFF4CC9F0);
        String t = (int) (p * 100) + "%"; c.drawText(tr, t, x + 78, yy + 6, WHITE, false); yy += 19; }
    }
  }

  // ---- Hit Counter (combo) ----
  public static class HitCounter extends Module {
    public HitCounter(){ super("Hit Counter", Cat.HUD); at(6, 40); }
    @Override public void tick(){ if (mc.player == null) return; if (mc.player.hurtTime == 9 || System.currentTimeMillis() - Astral.lastHit > 3500) Astral.combo = 0; }
    @Override public void hud(DrawContext c, float td){
      var tr = mc.textRenderer; String t = "Combo: " + Astral.combo; w = tr.getWidth(t) + 14; h = 18;
      RenderUtil.rrect(c, x, y, w, h, 5, BG); c.drawText(tr, "Combo:", x + 7, y + 5, GRAY, false); c.drawText(tr, "" + Astral.combo, x + 7 + tr.getWidth("Combo: "), y + 5, ACC, false);
    }
  }

  // ---- CPS (text only, no background) ----
  public static class Cps extends Module {
    static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
    final Setting right = add(Setting.bool("Right click", false));
    public Cps(){ super("CPS", Cat.HUD); at(6, 28); }
    public static void left(){ L.add(System.currentTimeMillis()); } public static void right(){ R.add(System.currentTimeMillis()); }
    static int count(ArrayDeque<Long> q){ long n = System.currentTimeMillis(); while (!q.isEmpty() && n - q.peekFirst() > 1000) q.pollFirst(); return q.size(); }
    @Override public void hud(DrawContext c, float td){
      String t = count(L) + (right.b ? " | " + count(R) : "") + " CPS"; w = mc.textRenderer.getWidth(t); h = 9; c.drawText(mc.textRenderer, t, x, y, WHITE, true);
    }
  }
}
