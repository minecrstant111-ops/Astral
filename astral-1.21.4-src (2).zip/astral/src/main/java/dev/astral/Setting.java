package dev.astral;
import net.minecraft.util.math.MathHelper;
public class Setting {
  public enum T { BOOL, NUM, MODE, COLOR, TEXT }
  public final String name; public final T type;
  public boolean b; public double n, min, max; public int mode; public String[] modes; public String text = "";
  private Setting(String name, T t){ this.name = name; this.type = t; }
  public static Setting bool(String n, boolean d){ Setting s = new Setting(n, T.BOOL); s.b = d; return s; }
  public static Setting num(String n, double d, double min, double max){ Setting s = new Setting(n, T.NUM); s.n = d; s.min = min; s.max = max; return s; }
  public static Setting mode(String n, int d, String... m){ Setting s = new Setting(n, T.MODE); s.mode = d; s.modes = m; return s; }
  public static Setting color(String n, double hue){ Setting s = new Setting(n, T.COLOR); s.n = hue; return s; }
  public static Setting text(String n, String d){ Setting s = new Setting(n, T.TEXT); s.text = d; return s; }
  public int rgb(){ return MathHelper.hsvToRgb((float) n, 0.65f, 1f) & 0xFFFFFF; }
  public String modeName(){ return modes[mode]; }
}
