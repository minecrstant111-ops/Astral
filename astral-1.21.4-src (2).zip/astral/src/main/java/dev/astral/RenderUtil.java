package dev.astral;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;
public class RenderUtil {
  static Vec3d cam = Vec3d.ZERO;
  // ---- 2D ----
  public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int argb){
    r = Math.min(r, Math.min(w, h) / 2);
    for (int i = 0; i < r; i++) {
      double dy = r - i - 0.5; int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
      c.fill(x + inset, y + i, x + w - inset, y + i + 1, argb);
      c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, argb);
    }
    c.fill(x, y + r, x + w, y + h - r, argb);
  }
  public static int rainbow(double off){ return MathHelper.hsvToRgb((float) (((System.currentTimeMillis() / 4000.0) + off) % 1.0), 0.65f, 1f) & 0xFFFFFF; }
  // ---- 3D ----
  public static Matrix4f view(WorldRenderContext c){ cam = c.camera().getPos(); return new Matrix4f(c.matrixStack().peek().getPositionMatrix()); }
  public static void begin(boolean depth){
    RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.disableCull();
    if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
    RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
  }
  public static void end(){ RenderSystem.enableDepthTest(); RenderSystem.enableCull(); RenderSystem.disableBlend(); }
  public static BufferBuilder qb(){ return Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR); }
  public static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int c){ b.vertex(m, (float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z)).color(c); }
  public static void flush(BufferBuilder b){ BuiltBuffer bb = b.endNullable(); if (bb != null) BufferRenderer.drawWithGlobalProgram(bb); }
  public static void quad(BufferBuilder b, Matrix4f m, double[] p1, double[] p2, double[] p3, double[] p4, int c){
    v(b, m, p1[0], p1[1], p1[2], c); v(b, m, p2[0], p2[1], p2[2], c); v(b, m, p3[0], p3[1], p3[2], c); v(b, m, p4[0], p4[1], p4[2], c);
  }
  public static void box(Matrix4f m, Box k, int c){
    BufferBuilder b = qb(); double a = k.minX, e = k.maxX, f = k.minY, g = k.maxY, h = k.minZ, i = k.maxZ;
    quad(b, m, new double[]{a,f,h}, new double[]{e,f,h}, new double[]{e,f,i}, new double[]{a,f,i}, c);
    quad(b, m, new double[]{a,g,h}, new double[]{a,g,i}, new double[]{e,g,i}, new double[]{e,g,h}, c);
    quad(b, m, new double[]{a,f,h}, new double[]{a,g,h}, new double[]{e,g,h}, new double[]{e,f,h}, c);
    quad(b, m, new double[]{a,f,i}, new double[]{e,f,i}, new double[]{e,g,i}, new double[]{a,g,i}, c);
    quad(b, m, new double[]{a,f,h}, new double[]{a,f,i}, new double[]{a,g,i}, new double[]{a,g,h}, c);
    quad(b, m, new double[]{e,f,h}, new double[]{e,g,h}, new double[]{e,g,i}, new double[]{e,f,i}, c);
    flush(b);
  }
  public static void ring(Matrix4f m, double cx, double cy, double cz, double r, double w, int seg, int c){
    BufferBuilder b = qb(); double r2 = r + w;
    for (int i = 0; i < seg; i++) {
      double a0 = Math.PI * 2 * i / seg, a1 = Math.PI * 2 * (i + 1) / seg;
      v(b, m, cx + Math.cos(a0) * r, cy, cz + Math.sin(a0) * r, c); v(b, m, cx + Math.cos(a0) * r2, cy, cz + Math.sin(a0) * r2, c);
      v(b, m, cx + Math.cos(a1) * r2, cy, cz + Math.sin(a1) * r2, c); v(b, m, cx + Math.cos(a1) * r, cy, cz + Math.sin(a1) * r, c);
    }
    flush(b);
  }
  public static void cone(Matrix4f m, double cx, double cy, double cz, double r, double hgt, int seg, int apex, int rim){
    BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
    v(b, m, cx, cy + hgt, cz, apex);
    for (int i = 0; i <= seg; i++) { double a = Math.PI * 2 * i / seg; v(b, m, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, rim); }
    flush(b);
  }
}
