package dev.astral.gui;
import java.util.*;
import java.util.function.*;
import dev.astral.Astral;
import dev.astral.Config;
import dev.astral.Module;
import dev.astral.RenderUtil;
import dev.astral.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Glass panels, one per category (Rival Visuals style). No dark header strip. */
public class ClickGui extends Screen {
  static final int PW = 132, RH = 16, ACC = 0xFF8B7CF6, TXT = 0xFFC8C8D6, WHITE = 0xFFFFFFFF;
  static final Module.Cat[] ORDER = { Module.Cat.COMBAT, Module.Cat.VISUALS, Module.Cat.UTILITY, Module.Cat.HUD };
  static final Map<String, String> DESC = new HashMap<>();
  static {
    String d = "Target ESP|Выделяет выбранную цель.\nNametags|Свои ники с HP и бронёй.\nHit Effect|Эффект при попадании по игроку.\nDamage Numbers|Показывает нанесённый урон над целью.\nHit Color|Свой цвет вспышки при ударе.\n"
      + "Trail|Светящийся след за игроком.\nHalo|Светящийся нимб над игроком.\nWorld Effects|Лучи у предметов и эффекты при наведении.\nCustom Sky|Своё время суток и цвет неба.\nCustom Crosshair|Полностью изменяемый прицел.\nCustom Block Outline|Кастомная обводка блока.\n"
      + "FOV Changer|Меняет угол обзора.\nTrajectory|Траектория стрел, жемчуга и зелий.\nFullbright|Максимальная яркость.\nTNT Timer|Таймер взрыва TNT.\nName Changer|Меняет ваш ник в табе и чате.\nFake Player|Добавляет фейк-игрока.\nNo Hurt Cam|Убирает тряску при ударе.\nFog|Изменение дальности тумана.\nSwing Animation|Настройка анимации взмаха.\nNo Fog|Убирает туман.\n"
      + "Aspect Ratio|Меняет пропорции экрана.\nChina Hat|Китайская шляпа над головой.\nJump Circles|Круги при прыжке.\nHitbox Customizer|Цвет хитбоксов.\nView Model|Позиция предмета в руке.\nItem Physic|Предметы лежат на земле.\nWeather|Погода только у вас.\nZoom|Приближение на клавишу C.\nNo Overlay|Убирает огонь и воду с экрана.\n"
      + "Tab Animation|Плавное появление таба.\nChat Animation|Плавное появление сообщений.\nAuction Helper|Подсвечивает предметы с низкой ценой.\nAuto Sprint|Бег без зажатия клавиши.\nAuto Respawn|Сам возрождается.\nItem Scroller|Перенос предметов Shift + мышь.\nToggle Sneak|Приседание по нажатию.\n"
      + "Watermark|FPS, пинг, время.\nInfo HUD|Координаты и скорость.\nArmor HUD|Броня и прочность справа от хотбара.\nTarget HUD|Информация о цели.\nPotion HUD|Активные эффекты зелий.\nCooldowns|Перезарядка предметов.\nKeybind HUD|Список ваших биндов.\nCPS|Клики в секунду.\nHit Counter|Счётчик комбо.\nKeystrokes|WASD и кнопки мыши.";
    for (String l : d.split("\n")) { String[] p = l.split("\\|"); DESC.put(p[0], p[1]); }
  }
  static final class Hit { final int x, y, w, h; final IntConsumer click; final DoubleConsumer drag;
    Hit(int x, int y, int w, int h, IntConsumer c, DoubleConsumer d){ this.x = x; this.y = y; this.w = w; this.h = h; click = c; drag = d; }
    boolean in(double mx, double my){ return mx >= x && mx < x + w && my >= y && my < y + h; } }
  final List<Hit> hits = new ArrayList<>(); Hit active; Setting typing; String hover = "", query = ""; boolean searching;
  final float[] scroll = new float[4], maxScroll = new float[4]; final int[] px = new int[4]; final boolean[] shown = new boolean[4];
  int visTop, visBot, sel = 0;

  public ClickGui(){ super(Text.literal("Astral Visuals")); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void removed(){ Config.save(); }
  void hit(int x, int y, int w, int h, IntConsumer c, DoubleConsumer d){ if (y + h > visTop && y < visBot) hits.add(new Hit(x, y, w, h, c, d)); }

  static void check(DrawContext c, int x, int y, int col){ int[][] p = { {0,3},{1,4},{2,5},{3,4},{4,3},{5,2},{6,1} }; for (int[] q : p) c.fill(x + q[0], y + q[1], x + q[0] + 1, y + q[1] + 2, col); }

  @Override public void render(DrawContext c, int mx, int my, float td){
    c.fill(0, 0, width, height, 0x55000000); hits.clear(); hover = ""; visTop = 0; visBot = height;
    int fit = MathHelper.clamp((width - 12) / (PW + 10), 1, 4), first = MathHelper.clamp(sel, 0, 4 - fit);
    int ph = Math.max(80, Math.min(height - 70, 300)), py = Math.max(30, (height - ph) / 2 + 6);
    if (fit < 4) { int tx = Math.max(4, (width - 4 * 52) / 2);
      for (int i = 0; i < 4; i++) { boolean act = i >= first && i < first + fit; RenderUtil.rrect(c, tx, 8, 50, 14, 7, act ? ACC : 0x88181A22); String l = ORDER[i].label; RenderUtil.text(c, l, tx + (50 - RenderUtil.tw(l)) / 2, 11, WHITE, false);
        final int ii = i; hit(tx, 8, 50, 14, b -> sel = ii, null); tx += 52; } }
    Arrays.fill(shown, false); int x0 = (width - (fit * PW + (fit - 1) * 10)) / 2;
    for (int k = 0; k < fit; k++) { int idx = first + k; px[idx] = x0 + k * (PW + 10); shown[idx] = true; panel(c, ORDER[idx], px[idx], py, ph, mx, my, idx); }
    if (!hover.isEmpty()) RenderUtil.text(c, hover, (width - RenderUtil.tw(hover)) / 2, Math.max(2, py - 16), WHITE, true);
    String hint = searching ? "Search: " + query + (System.currentTimeMillis() / 400 % 2 == 0 ? "_" : "") : "Ctrl+F - Search";
    RenderUtil.text(c, hint, (width - RenderUtil.tw(hint)) / 2, py + ph + 6, searching ? WHITE : 0xFF8E8E9C, false);
  }

  void panel(DrawContext c, Module.Cat cat, int pxx, int py, int ph, int mx, int my, int idx){
    RenderUtil.rrect(c, pxx, py, PW, ph, 10, 0xB0181A22);
    RenderUtil.text(c, cat.label, pxx + 10, py + 9, WHITE, false); RenderUtil.rrect(c, pxx + PW - 20, py + 8, 10, 10, 3, ACC);
    int top = py + 26; visTop = top; visBot = py + ph - 4; c.enableScissor(pxx, top, pxx + PW, visBot);
    int y = top + (int) scroll[idx];
    for (Module m : Astral.MODULES) {
      if (m.cat != cat || (!query.isEmpty() && !m.name.toLowerCase().contains(query.toLowerCase()))) continue;
      boolean hov = mx >= pxx + 4 && mx < pxx + PW - 4 && my >= y && my < y + RH && my >= top && my < visBot;
      if (hov) { RenderUtil.rrect(c, pxx + 4, y, PW - 8, RH - 1, 5, 0x28FFFFFF); hover = DESC.getOrDefault(m.name, ""); }
      RenderUtil.text(c, m.name, pxx + 10, y + 4, m.on ? WHITE : TXT, false);
      if (m.on) check(c, pxx + PW - 20, y + 3, 0xFFFFFFFF); else if (!m.settings.isEmpty()) RenderUtil.text(c, m.open ? "v" : ">", pxx + PW - 17, y + 4, 0xFF70707F, false);
      final Module mm = m; hit(pxx + 4, y, PW - 8, RH - 1, b -> { if (b == 0) mm.toggle(); else if (b == 1) mm.open = !mm.open; }, null);
      y += RH;
      if (m.open) for (Setting s : m.settings) y += setting(c, s, pxx + 10, y, PW - 20);
    }
    maxScroll[idx] = Math.max(0, (y - (int) scroll[idx]) - top - (ph - 30));
    c.disableScissor();
  }

  static String fmt(double v){ return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.2f", v); }

  int setting(DrawContext c, Setting s, int x, int y, int w){
    if (s.type == Setting.T.BOOL) {
      RenderUtil.text(c, s.name, x + 2, y + 3, 0xFFA9A9BA, false); int tx = x + w - 22;
      RenderUtil.rrect(c, tx, y + 2, 20, 10, 5, s.b ? ACC : 0xFF2B2B42); RenderUtil.rrect(c, tx + (s.b ? 11 : 1), y + 3, 8, 8, 4, 0xFFFFFFFF);
      hit(x, y, w, 14, b -> s.b = !s.b, null); return 15;
    } else if (s.type == Setting.T.NUM) {
      RenderUtil.text(c, s.name, x + 2, y + 1, 0xFFA9A9BA, false); String v = fmt(s.n); RenderUtil.text(c, v, x + w - 2 - RenderUtil.tw(v), y + 1, WHITE, false);
      RenderUtil.rrect(c, x + 2, y + 12, w - 4, 4, 2, 0xFF2B2B42); int fw = (int) ((s.n - s.min) / (s.max - s.min) * (w - 4)); RenderUtil.rrect(c, x + 2, y + 12, Math.max(fw, 4), 4, 2, ACC);
      final int bx = x + 2, bw = w - 4;
      hit(x, y, w, 20, null, mxx -> { double p = MathHelper.clamp((mxx - bx) / bw, 0, 1); s.n = Math.round((s.min + p * (s.max - s.min)) * 100) / 100.0; }); return 21;
    } else if (s.type == Setting.T.MODE) {
      RenderUtil.text(c, s.name, x + 2, y + 3, 0xFFA9A9BA, false); String v = "< " + s.modeName() + " >"; RenderUtil.text(c, v, x + w - 2 - RenderUtil.tw(v), y + 3, WHITE, false);
      hit(x, y, w, 14, b -> s.mode = Math.floorMod(s.mode + (b == 0 ? 1 : -1), s.modes.length), null); return 15;
    } else if (s.type == Setting.T.COLOR) {
      RenderUtil.text(c, s.name, x + 2, y + 1, 0xFFA9A9BA, false); int sw = w - 4;
      for (int i = 0; i < sw; i += 2) c.fill(x + 2 + i, y + 12, x + 4 + i, y + 17, 0xFF000000 | Setting.hsv(i / (float) sw, 1f, 1f));
      int mk = x + 2 + (int) (s.n * sw); c.fill(mk - 1, y + 10, mk + 1, y + 19, 0xFFFFFFFF); final int bx = x + 2;
      hit(x, y, w, 20, null, mxx -> s.n = MathHelper.clamp((mxx - bx) / sw, 0, 1)); return 21;
    } else {
      RenderUtil.text(c, s.name, x + 2, y + 1, 0xFFA9A9BA, false); boolean ty = typing == s;
      RenderUtil.rrect(c, x + 2, y + 11, w - 4, 12, 3, ty ? 0xFF2F2A55 : 0xFF23233A); RenderUtil.text(c, s.text + (ty && System.currentTimeMillis() / 400 % 2 == 0 ? "_" : ""), x + 5, y + 13, WHITE, false);
      hit(x, y, w, 24, b -> typing = s, null); return 25;
    }
  }

  @Override public boolean mouseClicked(double mx, double my, int button){
    typing = null;
    for (int i = hits.size() - 1; i >= 0; i--) { Hit h = hits.get(i); if (h.in(mx, my)) {
      if (h.click != null) h.click.accept(button); if (h.drag != null) { h.drag.accept(mx); active = h; } return true; } }
    return super.mouseClicked(mx, my, button);
  }
  @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy){ if (active != null && active.drag != null) { active.drag.accept(mx); return true; } return false; }
  @Override public boolean mouseReleased(double mx, double my, int b){ active = null; return super.mouseReleased(mx, my, b); }
  @Override public boolean mouseScrolled(double mx, double my, double hx, double vy){
    for (int i = 0; i < 4; i++) if (shown[i] && mx >= px[i] && mx < px[i] + PW) { scroll[i] = MathHelper.clamp(scroll[i] + (float) vy * 16, -maxScroll[i], 0); return true; }
    return false;
  }
  @Override public boolean keyPressed(int key, int sc, int mod){
    if (typing != null) { if (key == GLFW.GLFW_KEY_BACKSPACE && !typing.text.isEmpty()) typing.text = typing.text.substring(0, typing.text.length() - 1);
      else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) typing = null; return true; }
    if (key == GLFW.GLFW_KEY_F && (mod & GLFW.GLFW_MOD_CONTROL) != 0) { searching = true; return true; }
    if (searching) { if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) query = query.substring(0, query.length() - 1);
      else if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER) { searching = false; if (key == GLFW.GLFW_KEY_ESCAPE) query = ""; } return true; }
    if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
    return super.keyPressed(key, sc, mod);
  }
  @Override public boolean charTyped(char ch, int mod){
    if (typing != null && typing.text.length() < 16 && ch >= 32) { typing.text += ch; return true; }
    if (searching && query.length() < 20 && ch >= 32) { query += ch; return true; }
    return false;
  }
}
