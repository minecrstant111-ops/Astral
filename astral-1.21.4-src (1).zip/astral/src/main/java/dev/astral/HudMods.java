package dev.astral;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import dev.astral.gui.ClickGui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;

/** HUD in the Rival Visuals style: dark rounded cards, icon box, purple pills. */
public final class HudMods {
  private HudMods(){}
  static final int CARD = 0xCC1D1F28, PUR = 0xFF8B7CF6, PILL = 0xCC6D5BD0, WHITE = 0xFFFFFFFF, GRAY = 0xFFA4A7BA, ORG = 0xCCB5522C;
  static boolean editing(){ var s = Module.mc.currentScreen; return s instanceof ClickGui || s instanceof ChatScreen; }
  static void ico(DrawContext c, int x, int y, int col){ RenderUtil.rrect(c, x, y, 10, 10, 3, 0xFF000000 | col); c.fill(x + 4, y + 4, x + 6, y + 6, WHITE); }
  static int pill(DrawContext c, int x, int y, String t, int bg, int fg){ int w = RenderUtil.tw(t) + 10; RenderUtil.rrect(c, x, y, w, 13, 6, bg); RenderUtil.text(c, t, x + 5, y + 3, fg, false); return w; }

  // ---- Watermark: time | logo | fps | ping ----
  public static class Hud extends Module {
    final Setting time = add(Setting.bool("Time", true)), fps = add(Setting.bool("FPS", true)), ping = add(Setting.bool("Ping", true));
    static final DateTimeFormatter F = DateTimeFormatter.ofPattern("HH:mm");
    public Hud(){ super("Watermark", Cat.HUD); at(-1, 8); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<String[]> sg = new ArrayList<>();
      if (time.b) sg.add(new String[]{ "t", LocalTime.now().format(F) }); sg.add(new String[]{ "l", "" }); if (fps.b) sg.add(new String[]{ "f", mc.getCurrentFps() + " fps" });
      if (ping.b) { var e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()); sg.add(new String[]{ "p", (e == null ? 0 : e.getLatency()) + " ms" }); }
      int tot = 16; for (String[] s : sg) tot += (s[0].equals("l") ? 14 + RenderUtil.tw("Astral") + RenderUtil.tw("Visuals") : 14 + RenderUtil.tw(s[1])) + 14; tot -= 14;
      w = tot; h = 20; if (x < 0) x = (c.getScaledWindowWidth() - w) / 2; RenderUtil.rrect(c, x, y, w, h, 10, CARD);
      int cx = x + 8, cy = y + 5;
      for (String[] s : sg) {
        if (s[0].equals("l")) { ico(c, cx, cy, PUR); RenderUtil.text(c, "Astral", cx + 14, cy + 1, WHITE, false); RenderUtil.text(c, "Visuals", cx + 14 + RenderUtil.tw("Astral"), cy + 1, PUR, false); cx += 14 + RenderUtil.tw("Astral") + RenderUtil.tw("Visuals") + 14; }
        else { ico(c, cx, cy, s[0].equals("t") ? 0x6D5BD0 : 0x8B7CF6); RenderUtil.text(c, s[1], cx + 14, cy + 1, WHITE, false); cx += 14 + RenderUtil.tw(s[1]) + 14; }
      }
    }
  }

  // ---- Info: coords + speed ----
  public static class InfoHud extends Module {
    final Setting coords = add(Setting.bool("Coords", true)), speed = add(Setting.bool("Speed", true));
    public InfoHud(){ super("Info HUD", Cat.HUD); at(8, 34); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<String> p = new ArrayList<>();
      if (coords.b) p.add((int) mc.player.getX() + "x " + (int) mc.player.getY() + "y " + (int) mc.player.getZ() + "z");
      if (speed.b) p.add(String.format("%.2f bps", Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ) * 20));
      int tot = 16; for (String s : p) tot += 14 + RenderUtil.tw(s) + 14; tot -= 14; if (p.isEmpty()) tot = 40;
      w = tot; h = 20; RenderUtil.rrect(c, x, y, w, h, 7, CARD); int cx = x + 8;
      for (String s : p) { ico(c, cx, y + 5, 0x8B7CF6); RenderUtil.text(c, s, cx + 14, y + 6, WHITE, false); cx += 14 + RenderUtil.tw(s) + 14; }
    }
  }

  // ---- Armor HUD: fixed, right of the hotbar ----
  public static class ArmorHud extends Module {
    static final EquipmentSlot[] S = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    public ArmorHud(){ super("Armor HUD", Cat.HUD); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; x = c.getScaledWindowWidth() / 2 + 98; y = c.getScaledWindowHeight() - 40; w = 84; h = 34; RenderUtil.rrect(c, x, y, w, h, 8, CARD);
      for (int i = 0; i < 4; i++) { ItemStack s = mc.player.getEquippedStack(S[i]); int ix = x + 3 + i * 20; if (s.isEmpty()) continue; c.drawItem(s, ix, y + 3);
        if (s.isDamageable()) { int pct = 100 - s.getDamage() * 100 / s.getMaxDamage(); String t = pct + "%"; int col = 0xFF000000 | Setting.hsv(pct / 300f, 1f, 1f);
          c.getMatrices().push(); c.getMatrices().translate(ix + 8 - RenderUtil.tw(t) * 0.3f, y + 22, 0); c.getMatrices().scale(0.6f, 0.6f, 1); RenderUtil.text(c, t, 0, 0, col, true); c.getMatrices().pop(); } }
    }
  }

  // ---- Target HUD ----
  public static class TargetHud extends Module {
    final Setting head = add(Setting.bool("Head", true)), armor = add(Setting.bool("Armor", true)), dist = add(Setting.bool("Distance", true)), anim = add(Setting.bool("Animation", true));
    float shown = 20, slide;
    public TargetHud(){ super("Target HUD", Cat.HUD); at(-1, -1); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; if (x < 0) { x = c.getScaledWindowWidth() / 2 + 20; y = c.getScaledWindowHeight() / 2 + 20; }
      LivingEntity t = Astral.target; boolean act = t != null && t.isAlive() && System.currentTimeMillis() - Astral.targetTime < 5000; if (!act) t = editing() ? mc.player : null;
      slide += ((t != null ? 1 : 0) - slide) * (anim.b ? 0.2f : 1f); if (t == null && slide < 0.03f) return; if (t == null) return;
      float hp = t.getHealth() + t.getAbsorptionAmount(), max = Math.max(1, t.getMaxHealth()); shown += (hp - shown) * (anim.b ? 0.15f : 1f);
      boolean small = head.b; int hx = small ? 44 : 10; w = 150; h = (armor.b || dist.b) ? 46 : 38; int dx = anim.b ? (int) ((1 - slide) * -20) : 0; int px = x + dx;
      RenderUtil.rrect(c, px, y, w, h, 10, CARD);
      if (small) { if (t instanceof AbstractClientPlayerEntity ap) PlayerSkinDrawer.draw(c, ap.getSkinTextures(), px + 6, y + 6, 30); else { RenderUtil.rrect(c, px + 6, y + 6, 30, 30, 6, 0xFF3A3D4C); RenderUtil.text(c, t.getName().getString().substring(0, 1), px + 18, y + 17, WHITE, false); } }
      RenderUtil.text(c, t.getName().getString(), px + hx, y + 8, WHITE, false); String hs = (int) Math.ceil(hp) + "hp"; RenderUtil.text(c, hs, px + w - 8 - RenderUtil.tw(hs), y + 8, PUR, false);
      int bx = px + hx, bw = w - hx - 8; RenderUtil.rrect(c, bx, y + 22, bw, 6, 3, 0xFF2B2D3A); RenderUtil.rrect(c, bx, y + 22, Math.max(6, (int) (bw * MathHelper.clamp(shown / max, 0, 1))), 6, 3, PUR);
      if (armor.b || dist.b) { String s = (armor.b ? "Armor " + t.getArmor() : "") + (armor.b && dist.b ? "  |  " : "") + (dist.b ? String.format("%.1fm", t.distanceTo(mc.player)) : ""); RenderUtil.text(c, s, bx, y + 34, GRAY, false); }
    }
  }

  // ---- Potions ----
  public static class PotionHud extends Module {
    public PotionHud(){ super("Potion HUD", Cat.HUD); at(8, 70); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<Object[]> r = new ArrayList<>();
      for (StatusEffectInstance e : mc.player.getStatusEffects()) { int sec = e.getDuration() / 20; r.add(new Object[]{ e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1), e.isInfinite() ? "inf" : String.format("%02d:%02d", sec / 60, sec % 60), e.getEffectType().value().isBeneficial() }); }
      if (r.isEmpty() && editing()) r.add(new Object[]{ "Potions", "00:21", true }); if (r.isEmpty()) { w = 60; h = 14; return; }
      int mw = 0; for (Object[] o : r) mw = Math.max(mw, RenderUtil.tw((String) o[0]) + RenderUtil.tw((String) o[1]) + 30);
      w = 34 + mw; h = r.size() * 16 + 8; RenderUtil.rrect(c, x, y, w, h, 8, CARD); RenderUtil.rrect(c, x, y, 26, h, 8, 0x55000000); ico(c, x + 8, y + h / 2 - 5, 0x8B7CF6);
      for (int i = 0; i < r.size(); i++) { Object[] o = r.get(i); int yy = y + 6 + i * 16; RenderUtil.text(c, (String) o[0], x + 32, yy + 3, (boolean) o[2] ? WHITE : 0xFFFCA5A5, false); pill(c, x + w - 8 - (RenderUtil.tw((String) o[1]) + 10), yy, (String) o[1], PILL, WHITE); }
    }
  }

  // ---- Cooldowns (items + attack) ----
  public static class CooldownsHud extends Module {
    static final Item[] ITEMS = { Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.SHIELD, Items.WIND_CHARGE, Items.TRIDENT, Items.CROSSBOW, Items.FIREWORK_ROCKET, Items.SNOWBALL };
    static final int[] TOT = { 20, 0, 0, 20, 100, 10, 0, 0, 0, 4 };
    public CooldownsHud(){ super("Cooldowns", Cat.HUD); at(8, 120); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<Object[]> r = new ArrayList<>();
      for (int i = 0; i < ITEMS.length; i++) { ItemStack st = new ItemStack(ITEMS[i]); float p = mc.player.getItemCooldownManager().getCooldownProgress(st, td);
        if (p > 0) r.add(new Object[]{ st, TOT[i] > 0 ? String.format("%02d:%02d", (int) (p * TOT[i] / 20), (int) (p * TOT[i] / 20 * 100) % 100) : (int) (p * 100) + "%" }); }
      if (r.isEmpty() && editing()) r.add(new Object[]{ new ItemStack(Items.ENDER_PEARL), "00:09" }); if (r.isEmpty()) { w = 60; h = 14; return; }
      w = 110; h = r.size() * 20 + 6; RenderUtil.rrect(c, x, y, w, h, 8, CARD); RenderUtil.rrect(c, x, y, 26, h, 8, 0x55000000);
      for (int i = 0; i < r.size(); i++) { int yy = y + 4 + i * 20; c.drawItem((ItemStack) r.get(i)[0], x + 5, yy); RenderUtil.text(c, "Cooldowns", x + 32, yy + 4, WHITE, false); pill(c, x + w - 8 - (RenderUtil.tw((String) r.get(i)[1]) + 10), yy + 2, (String) r.get(i)[1], ORG, 0xFFFFB4A0); }
    }
  }

  // ---- Keybinds ----
  public static class KeybindHud extends Module {
    public KeybindHud(){ super("Keybind HUD", Cat.HUD); at(8, 200); on = true; }
    @Override public void hud(DrawContext c, float td){
      List<String[]> r = new ArrayList<>(); for (Module m : Astral.MODULES) if (m.key >= 0) r.add(new String[]{ m.name, Astral.keyName(m.key) });
      if (r.isEmpty() && editing()) r.add(new String[]{ "Fast Swap", "B" }); if (r.isEmpty()) { w = 60; h = 14; return; }
      int mw = 0; for (String[] s : r) mw = Math.max(mw, RenderUtil.tw(s[0]) + RenderUtil.tw(s[1]) + 32);
      w = 34 + mw; h = r.size() * 16 + 8; RenderUtil.rrect(c, x, y, w, h, 8, CARD); RenderUtil.rrect(c, x, y, 26, h, 8, 0x55000000); ico(c, x + 8, y + h / 2 - 5, 0x8B7CF6);
      for (int i = 0; i < r.size(); i++) { int yy = y + 6 + i * 16; RenderUtil.text(c, r.get(i)[0], x + 32, yy + 3, GRAY, false); pill(c, x + w - 8 - (RenderUtil.tw(r.get(i)[1]) + 10), yy, r.get(i)[1], PILL, WHITE); }
    }
  }

  // ---- extras ----
  public static class Cps extends Module {
    static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
    final Setting right = add(Setting.bool("Right click", false));
    public Cps(){ super("CPS", Cat.HUD); at(8, 240); }
    public static void left(){ L.add(System.currentTimeMillis()); } public static void right(){ R.add(System.currentTimeMillis()); }
    static int count(ArrayDeque<Long> q){ long n = System.currentTimeMillis(); while (!q.isEmpty() && n - q.peekFirst() > 1000) q.pollFirst(); return q.size(); }
    @Override public void hud(DrawContext c, float td){ String t = count(L) + (right.b ? " | " + count(R) : "") + " CPS"; w = RenderUtil.tw(t); h = 9; RenderUtil.text(c, t, x, y, WHITE, true); }
  }
  public static class HitCounter extends Module {
    int prevHurt;
    public HitCounter(){ super("Hit Counter", Cat.HUD); at(8, 256); }
    @Override public void tick(){ if (mc.player == null) return; int hu = mc.player.hurtTime; if (hu > prevHurt || System.currentTimeMillis() - Astral.lastHit > 3500) Astral.combo = 0; prevHurt = hu; }
    @Override public void hud(DrawContext c, float td){ String t = "Combo: " + Astral.combo; w = RenderUtil.tw(t) + 14; h = 18; RenderUtil.rrect(c, x, y, w, h, 7, CARD); RenderUtil.text(c, "Combo:", x + 7, y + 5, GRAY, false); RenderUtil.text(c, "" + Astral.combo, x + 7 + RenderUtil.tw("Combo: "), y + 5, PUR, false); }
  }
  public static class Keystrokes extends Module {
    public Keystrokes(){ super("Keystrokes", Cat.HUD); at(8, 280); }
    void key(DrawContext c, int kx, int ky, int kw, int kh, String s, boolean down){ RenderUtil.rrect(c, kx, ky, kw, kh, 5, down ? 0xE08B7CF6 : CARD); RenderUtil.text(c, s, kx + (kw - RenderUtil.tw(s)) / 2, ky + (kh - 8) / 2, down ? WHITE : GRAY, false); }
    @Override public void hud(DrawContext c, float td){
      var o = mc.options; w = 64; h = 64;
      key(c, x + 22, y, 20, 20, "W", o.forwardKey.isPressed()); key(c, x, y + 22, 20, 20, "A", o.leftKey.isPressed()); key(c, x + 22, y + 22, 20, 20, "S", o.backKey.isPressed()); key(c, x + 44, y + 22, 20, 20, "D", o.rightKey.isPressed());
      key(c, x, y + 44, 31, 20, "LMB", o.attackKey.isPressed()); key(c, x + 33, y + 44, 31, 20, "RMB", o.useKey.isPressed());
    }
  }
}
