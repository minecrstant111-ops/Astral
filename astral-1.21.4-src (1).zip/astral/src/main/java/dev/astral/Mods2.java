package dev.astral;
import java.util.*;
import com.mojang.authlib.GameProfile;
import dev.astral.mixin.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

public final class Mods2 {
  private Mods2(){}
  static final int PUR = 0xFF8B7CF6;

  // ================= Utils: animations =================
  public static class TabAnimation extends Module {
    final Setting speed = add(Setting.num("Speed", 1, 0.3, 3)), smooth = add(Setting.num("Smooth", 0.5, 0, 1));
    float p; long last = System.nanoTime();
    public TabAnimation(){ super("Tab Animation", Cat.UTILITY); }
    @Override public void tick(){ if (!mc.options.playerListKey.isPressed()) { p = 0; last = System.nanoTime(); } }
    public float offset(){ long n = System.nanoTime(); float dt = (n - last) / 1e9f; last = n; p = Math.min(1, p + dt * (float) speed.n * 3); return -(float) ((1 - Mods.ease(p, smooth.n)) * 70); }
  }
  public static class ChatAnimation extends Module {
    final Setting speed = add(Setting.num("Speed", 1, 0.3, 3)), smooth = add(Setting.num("Smooth", 0.5, 0, 1));
    float off; long last = System.nanoTime();
    public ChatAnimation(){ super("Chat Animation", Cat.UTILITY); }
    public void newMsg(){ off = 9; }
    public float offset(){ long n = System.nanoTime(); float dt = (n - last) / 1e9f; last = n; off *= (float) Math.exp(-dt * speed.n * (4 + 10 * (1 - smooth.n))); return off; }
  }
  // ================= Utils: auction helper =================
  public static class AuctionHelper extends Module {
    final Setting tol = add(Setting.num("Tolerance %", 5, 0, 100)), armor = add(Setting.bool("Armor", true)), sword = add(Setting.bool("Swords", true)), gapple = add(Setting.bool("Gapples", true)), other = add(Setting.bool("Other / perks", false));
    public AuctionHelper(){ super("Auction Helper", Cat.UTILITY); }
    static double price(ItemStack st){
      LoreComponent lore = st.get(DataComponentTypes.LORE); if (lore == null) return -1;
      var pat = java.util.regex.Pattern.compile("(?:\u0446\u0435\u043d\u0430|price|\u0441\u0442\u043e\u0438\u043c\u043e\u0441\u0442\u044c|\\$)\\D{0,14}(\\d[\\d\\s.,]*)");
      for (net.minecraft.text.Text t : lore.lines()) { var mt = pat.matcher(t.getString().toLowerCase());
        if (mt.find()) { String d = mt.group(1).replaceAll("\\D", ""); if (!d.isEmpty() && d.length() < 15) return Double.parseDouble(d); } }
      return -1;
    }
    boolean pass(String id){
      if (id.contains("helmet") || id.contains("chestplate") || id.contains("leggings") || id.contains("boots")) return armor.b;
      if (id.contains("sword")) return sword.b; if (id.contains("golden_apple")) return gapple.b; return other.b;
    }
    public static void render(HandledScreen<?> hs, DrawContext c){
      AuctionHelper m = Astral.get(AuctionHelper.class); if (m == null || !m.on) return;
      var acc = (HandledScreenAccessor) hs; int ox = acc.astral$getX(), oy = acc.astral$getY();
      Map<String, Double> best = new HashMap<>(); List<Object[]> cand = new ArrayList<>();
      for (Slot s : hs.getScreenHandler().slots) {
        ItemStack st = s.getStack(); if (st.isEmpty() || s.inventory instanceof PlayerInventory) continue;
        double p = price(st); if (p < 0) continue; String id = Registries.ITEM.getId(st.getItem()).getPath(); if (!m.pass(id)) continue;
        double unit = p / st.getCount(); best.merge(id, unit, Math::min); cand.add(new Object[]{ s, id, unit });
      }
      for (Object[] o : cand) { double unit = (double) o[2], b = best.get((String) o[1]);
        if (unit <= b * (1 + m.tol.n / 100.0)) { Slot s = (Slot) o[0]; c.fill(ox + s.x, oy + s.y, ox + s.x + 16, oy + s.y + 16, 0x9900E060); } }
    }
  }

  // ================= Combat =================
  public static class Nametags extends Module {
    final Setting size = add(Setting.num("Size", 1, 0.5, 3)), custom = add(Setting.bool("Custom color", false)), color = add(Setting.color("Color", 0.75)), bg = add(Setting.bool("Background", true));
    final Setting hp = add(Setting.bool("Health", true)), armor = add(Setting.bool("Armor", true)), dist = add(Setting.bool("Distance", false)), self = add(Setting.bool("Self (3rd person)", false));
    public Nametags(){ super("Nametags", Cat.COMBAT); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.world == null) return;
      for (PlayerEntity p : mc.world.getPlayers()) {
        if (p == mc.player && !(self.b && c.camera().isThirdPerson())) continue; if (p.isInvisible()) continue;
        Vec3d pos = Mods.lerp(p, td); double d = pos.distanceTo(c.camera().getPos()); String n = p.getName().getString();
        StringBuilder sb = new StringBuilder(n);
        if (hp.b) sb.append("  ").append(String.format("%.1f", p.getHealth() + p.getAbsorptionAmount()));
        if (armor.b) sb.append("  A").append(p.getArmor()); if (dist.b) sb.append("  ").append((int) d).append("m");
        int col = Astral.isFriend(n) ? 0xFF55FF55 : custom.b ? 0xFF000000 | color.rgb() : 0xFFFFFFFF;
        RenderUtil.worldText(c, sb.toString(), pos.x, pos.y + p.getHeight() + 0.55, pos.z, (float) (size.n * Math.max(1, d * 0.09)), col, bg.b);
      }
    }
  }
  public static class HitEffect extends Module {
    public final Setting style = add(Setting.mode("Style", 2, "Particles", "Flash", "Rings", "Wave", "Cubes", "Diamonds")), color = add(Setting.color("Color", 0.78)), rainbow = add(Setting.bool("Rainbow", false));
    final Setting size = add(Setting.num("Size", 1, 0.5, 3)), count = add(Setting.num("Count", 12, 3, 30)), dur = add(Setting.num("Duration", 0.8, 0.3, 2)), speed = add(Setting.num("Speed", 1, 0.5, 3));
    final List<double[]> list = new ArrayList<>();
    public HitEffect(){ super("Hit Effect", Cat.COMBAT); }
    public void spawn(Entity e){
      if (mc.world == null) return;
      if (style.mode == 0) { var r = java.util.concurrent.ThreadLocalRandom.current();
        for (int i = 0; i < (int) count.n; i++) mc.world.addParticle(net.minecraft.particle.ParticleTypes.CRIT, e.getX() + (r.nextDouble() - 0.5) * e.getWidth(), e.getY() + r.nextDouble() * e.getHeight(), e.getZ() + (r.nextDouble() - 0.5) * e.getWidth(), (r.nextDouble() - 0.5) * 0.5, r.nextDouble() * 0.4, (r.nextDouble() - 0.5) * 0.5); }
      else list.add(new double[]{ e.getX(), e.getY() + e.getHeight() / 2, e.getZ(), System.nanoTime(), Math.random() * 100, e.getHeight(), e.getWidth() });
    }
    static void diamond(Matrix4f m, double x, double y, double z, double r, int c){
      BufferBuilder b = RenderUtil.qb(); double[][] p = { { x + r, y, z }, { x, y, z + r }, { x - r, y, z }, { x, y, z - r } };
      for (int i = 0; i < 4; i++) { double[] a = p[i], d = p[(i + 1) % 4];
        RenderUtil.quad(b, m, new double[]{ x, y + r * 1.4, z }, a, d, d, c); RenderUtil.quad(b, m, new double[]{ x, y - r * 1.4, z }, d, a, a, c); }
      RenderUtil.flush(b);
    }
    @Override public void world(WorldRenderContext c, float td){
      long now = System.nanoTime(); list.removeIf(k -> (now - k[3]) / 1e9 > dur.n); if (list.isEmpty()) return;
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true);
      for (double[] k : list) {
        double t = (now - k[3]) / 1e9 / dur.n, a = 1 - t; int rgb = Mods.col(color, rainbow, t);
        switch (style.mode) {
          case 1 -> { double s = (0.4 + t * 0.6) * size.n * Math.max(k[5], k[6]); RenderUtil.box(m, new Box(k[0] - s / 2, k[1] - s / 2, k[2] - s / 2, k[0] + s / 2, k[1] + s / 2, k[2] + s / 2), Mods.argb(a * 0.55, rgb)); }
          case 2 -> { for (int i = 0; i < 3; i++) { double tt = t * 1.5 - i * 0.25; if (tt <= 0 || tt >= 1) continue; RenderUtil.ring(m, k[0], k[1], k[2], 0.2 + size.n * 1.4 * Mods.ease(tt, 0.5), 0.06, 32, Mods.argb(1 - tt, rgb)); } }
          case 3 -> RenderUtil.ring(m, k[0], k[1] - k[5] / 2 + 0.05, k[2], 0.2 + size.n * 2.6 * Mods.ease(t, 0.3), 0.12 * size.n, 40, Mods.argb(a * 0.9, rgb));
          default -> { int n = (int) count.n; for (int i = 0; i < n; i++) {
            double ang = k[4] + i * 2.39996, ph = Math.acos(1 - 2.0 * (i + 0.5) / n), d = speed.n * size.n * 1.6 * Mods.ease(t, 0.4);
            double px = k[0] + Math.cos(ang) * Math.sin(ph) * d, py = k[1] + Math.cos(ph) * d - 0.7 * t * t, pz = k[2] + Math.sin(ang) * Math.sin(ph) * d, hs = 0.07 * size.n * (1 - t) + 0.01;
            if (style.mode == 4) RenderUtil.box(m, new Box(px - hs, py - hs, pz - hs, px + hs, py + hs, pz + hs), Mods.argb(a, rgb)); else diamond(m, px, py, pz, hs * 1.6, Mods.argb(a, rgb)); } }
        }
      }
      RenderUtil.end();
    }
  }
  public static class DamageNumbers extends Module {
    final Setting size = add(Setting.num("Size", 1.2, 0.5, 3)), color = add(Setting.color("Color", 0.12)), crit = add(Setting.color("Crit color", 0.0));
    final Setting pos = add(Setting.mode("Position", 0, "Above", "Side")), anim = add(Setting.mode("Animation", 0, "Float", "Pop", "Fall")), time = add(Setting.num("Time (s)", 1.2, 0.4, 3));
    final List<double[]> list = new ArrayList<>(); float lastHp; int lastId = -1;
    public DamageNumbers(){ super("Damage Numbers", Cat.COMBAT); }
    @Override public void tick(){
      LivingEntity t = Astral.target; if (t == null || !t.isAlive() || System.currentTimeMillis() - Astral.targetTime > 4000) { lastId = -1; return; }
      float hp = t.getHealth() + t.getAbsorptionAmount();
      if (t.getId() == lastId && lastHp > hp + 0.05f) { var r = java.util.concurrent.ThreadLocalRandom.current(); double side = pos.mode == 1 ? (r.nextDouble() - 0.5) * 1.4 : 0;
        list.add(new double[]{ t.getX() + side, t.getY() + t.getHeight() + 0.3, t.getZ() + side, System.nanoTime(), lastHp - hp, Astral.lastCrit ? 1 : 0 }); }
      lastId = t.getId(); lastHp = hp;
    }
    @Override public void world(WorldRenderContext c, float td){
      long now = System.nanoTime(); list.removeIf(k -> (now - k[3]) / 1e9 > time.n);
      for (double[] k : list) {
        double t = (now - k[3]) / 1e9 / time.n; double sc = size.n, yy = k[1];
        switch (anim.mode) { case 0 -> yy += t * 0.8; case 1 -> { sc *= t < 0.15 ? 0.5 + t / 0.15 * 0.8 : 1.3 - Math.min(0.3, (t - 0.15) * 0.5); yy += t * 0.3; } default -> yy += 0.4 - t * 0.7; }
        int a = Math.max(8, (int) (255 * Math.min(1, (1 - t) * 2.5))); int rgb = k[5] > 0 ? crit.rgb() : color.rgb();
        RenderUtil.worldText(c, String.format("%.1f", k[4]) + (k[5] > 0 ? "!" : ""), k[0], yy, k[2], (float) sc, (a << 24) | rgb, false);
      }
    }
  }

  // ================= Visuals =================
  public static class Halo extends Module {
    final Setting shape = add(Setting.mode("Shape", 0, "Ring", "Double", "Dots")), color = add(Setting.color("Color", 0.12)), rainbow = add(Setting.bool("Rainbow", false));
    final Setting size = add(Setting.num("Size", 0.32, 0.15, 0.8)), rot = add(Setting.num("Rotation", 1.5, 0, 5)), glow = add(Setting.bool("Glow", true));
    public Halo(){ super("Halo", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.player == null || !c.camera().isThirdPerson()) return; Vec3d p = Mods.lerp(mc.player, td); long ms = System.currentTimeMillis();
      double y = p.y + mc.player.getHeight() + 0.22 + Math.sin(ms / 500.0) * 0.02, r = size.n; int rgb = Mods.col(color, rainbow, 0);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(false);
      if (glow.b) RenderUtil.ring(m, p.x, y, p.z, r - 0.09, 0.18, 48, Mods.argb(0.15, rgb));
      switch (shape.mode) {
        case 0 -> RenderUtil.ring(m, p.x, y, p.z, r - 0.03, 0.06, 48, Mods.argb(0.95, rgb));
        case 1 -> { RenderUtil.ring(m, p.x, y, p.z, r - 0.03, 0.05, 48, Mods.argb(0.95, rgb)); RenderUtil.ring(m, p.x, y + 0.1, p.z, r * 0.8 - 0.03, 0.05, 48, Mods.argb(0.8, rgb)); }
        default -> { double a0 = ms / 1000.0 * rot.n; for (int i = 0; i < 10; i++) { double a = a0 + i * Math.PI / 5, px = p.x + Math.cos(a) * r, pz = p.z + Math.sin(a) * r;
          RenderUtil.box(m, new Box(px - 0.035, y - 0.035, pz - 0.035, px + 0.035, y + 0.035, pz + 0.035), Mods.argb(0.95, rgb)); } }
      }
      RenderUtil.end();
    }
  }
  public static class WorldEffects extends Module {
    final Setting beams = add(Setting.bool("Loot beams", true)), height = add(Setting.num("Beam height", 1.5, 0.5, 5)), hover = add(Setting.bool("Hover particles", false));
    static final int[] RAR = { 0xFFFFFF, 0xFFFF55, 0x55FFFF, 0xFF55FF };
    int tk;
    public WorldEffects(){ super("World Effects", Cat.VISUALS); }
    @Override public void tick(){
      if (!hover.b || mc.world == null || ++tk % 3 != 0 || !(mc.crosshairTarget instanceof BlockHitResult h) || h.getType() != HitResult.Type.BLOCK) return;
      Vec3d v = h.getPos(); mc.world.addParticle(net.minecraft.particle.ParticleTypes.END_ROD, v.x, v.y + 0.05, v.z, 0, 0.02, 0);
    }
    @Override public void world(WorldRenderContext c, float td){
      if (!beams.b || mc.world == null) return; Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true);
      for (Entity e : mc.world.getEntities()) if (e instanceof ItemEntity ie) {
        Vec3d p = Mods.lerp(e, td); int rgb = RAR[Math.min(3, ie.getStack().getRarity().ordinal())];
        RenderUtil.box(m, new Box(p.x - 0.025, p.y, p.z - 0.025, p.x + 0.025, p.y + height.n, p.z + 0.025), Mods.argb(0.8, rgb));
        RenderUtil.box(m, new Box(p.x - 0.08, p.y, p.z - 0.08, p.x + 0.08, p.y + height.n, p.z + 0.08), Mods.argb(0.2, rgb));
      }
      RenderUtil.end();
    }
  }
  public static class CustomSky extends Module {
    public final Setting useTime = add(Setting.bool("Custom time", true)), time = add(Setting.num("Time (h)", 12, 0, 24)), useColor = add(Setting.bool("Custom color", false)), color = add(Setting.color("Sky color", 0.75));
    public CustomSky(){ super("Custom Sky", Cat.VISUALS); }
    @Override public void tick(){ if (useTime.b && mc.world != null) mc.world.getLevelProperties().setTimeOfDay((long) (((time.n - 6 + 24) % 24) * 1000)); }
  }
  public static class CustomBlockOutline extends Module {
    final Setting color = add(Setting.color("Color", 0.75)), rainbow = add(Setting.bool("Rainbow", false)), fill = add(Setting.bool("Fill", true)), outline = add(Setting.bool("Outline", true));
    final Setting thick = add(Setting.num("Thickness", 0.02, 0.005, 0.06)), alpha = add(Setting.num("Alpha", 0.3, 0.05, 1)), glow = add(Setting.bool("Glow", false));
    public CustomBlockOutline(){ super("Custom Block Outline", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.world == null || !(mc.crosshairTarget instanceof BlockHitResult h) || h.getType() != HitResult.Type.BLOCK) return;
      BlockPos p = h.getBlockPos(); VoxelShape sh = mc.world.getBlockState(p).getOutlineShape(mc.world, p); if (sh.isEmpty()) return;
      Box b = sh.getBoundingBox().offset(p).expand(0.002); int rgb = Mods.col(color, rainbow, 0);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true);
      if (glow.b) RenderUtil.box(m, b.expand(0.04), Mods.argb(alpha.n * 0.35, rgb));
      if (fill.b) RenderUtil.box(m, b, Mods.argb(alpha.n, rgb));
      if (outline.b) RenderUtil.edges(m, b, thick.n, Mods.argb(1, rgb));
      RenderUtil.end();
    }
  }
  public static class FovChanger extends Module {
    final Setting fov = add(Setting.num("FOV", 100, 30, 150)); Integer old;
    public FovChanger(){ super("FOV Changer", Cat.VISUALS); }
    void set(int v){ ((SimpleOptionAccessor) (Object) mc.options.getFov()).astral$setValue(Integer.valueOf(v)); }
    @Override public void onEnable(){ old = mc.options.getFov().getValue(); }
    @Override public void tick(){ if (!(Astral.zoomKey != null && Astral.zoomKey.isPressed() && Astral.on(Mods.Zoom.class))) set((int) fov.n); }
    @Override public void onDisable(){ if (old != null) set(old); }
  }
  public static class Trajectory extends Module {
    public Trajectory(){ super("Trajectory", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      var pl = mc.player; if (pl == null || mc.world == null) return;
      double speed = 0, grav = 0.03, pitchOff = 0; ItemStack st = pl.getMainHandStack(); Item it = st.getItem();
      if (!(it instanceof BowItem || it instanceof CrossbowItem || it instanceof TridentItem || it instanceof EnderPearlItem || it instanceof SnowballItem || it instanceof EggItem || it instanceof ThrowablePotionItem || it instanceof ExperienceBottleItem)) { st = pl.getOffHandStack(); it = st.getItem(); }
      if (it instanceof BowItem) { if (!pl.isUsingItem()) return; float pull = BowItem.getPullProgress(pl.getItemUseTime()); if (pull < 0.1f) return; speed = pull * 3; grav = 0.05; }
      else if (it instanceof CrossbowItem) { if (!CrossbowItem.isCharged(st)) return; speed = 3.15; grav = 0.05; }
      else if (it instanceof TridentItem) { if (!pl.isUsingItem()) return; speed = 2.5; grav = 0.05; }
      else if (it instanceof ThrowablePotionItem) { speed = 0.5; grav = 0.05; pitchOff = -20; }
      else if (it instanceof ExperienceBottleItem) { speed = 0.7; grav = 0.07; pitchOff = -20; }
      else if (it instanceof EnderPearlItem || it instanceof SnowballItem || it instanceof EggItem) speed = 1.5; else return;
      double yaw = Math.toRadians(pl.getYaw()), pit = Math.toRadians(pl.getPitch() + pitchOff);
      Vec3d pos = pl.getCameraPosVec(td);
      Vec3d vel = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit)).multiply(speed);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true); com.mojang.blaze3d.systems.RenderSystem.lineWidth(2.5f);
      BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR); int col = PUR; Vec3d end = null;
      RenderUtil.v(b, m, pos.x, pos.y - 0.05, pos.z, col);
      for (int i = 0; i < 120; i++) {
        Vec3d next = pos.add(vel); BlockHitResult hr = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, pl));
        if (hr.getType() != HitResult.Type.MISS) { end = hr.getPos(); RenderUtil.v(b, m, end.x, end.y, end.z, col); break; }
        pos = next; vel = vel.multiply(0.99).add(0, -grav, 0); RenderUtil.v(b, m, pos.x, pos.y, pos.z, col);
      }
      RenderUtil.flush(b); com.mojang.blaze3d.systems.RenderSystem.lineWidth(1f);
      if (end != null) RenderUtil.ring(m, end.x, end.y + 0.02, end.z, 0.12, 0.05, 16, 0xE68B7CF6);
      RenderUtil.end();
    }
  }
  public static class TntTimer extends Module {
    final Setting size = add(Setting.num("Size", 1.4, 0.5, 3)), color = add(Setting.color("Color", 0.0)), fmt = add(Setting.mode("Format", 0, "0.0s", "ticks", "mm:ss")), pulse = add(Setting.bool("Pulse", true)), above = add(Setting.mode("Position", 0, "Above", "Center"));
    public TntTimer(){ super("TNT Timer", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.world == null) return;
      for (Entity e : mc.world.getEntities()) if (e instanceof TntEntity t) {
        int f = t.getFuse(); String s = switch (fmt.mode) { case 1 -> f + "t"; case 2 -> (f / 20) / 60 + ":" + String.format("%02d", (f / 20) % 60); default -> String.format("%.1fs", f / 20.0); };
        double sc = size.n * (pulse.b && f < 20 ? 1 + 0.25 * Math.sin(System.currentTimeMillis() / 60.0) : 1); Vec3d p = Mods.lerp(e, td);
        RenderUtil.worldText(c, s, p.x, p.y + (above.mode == 0 ? e.getHeight() + 0.6 : e.getHeight() / 2), p.z, (float) sc, 0xFF000000 | color.rgb(), true);
      }
    }
  }
  public static class FakePlayer extends Module {
    final Setting name = add(Setting.text("Name", "Steve")); OtherClientPlayerEntity fake;
    public FakePlayer(){ super("Fake Player", Cat.VISUALS); }
    @Override public void onEnable(){
      if (mc.world == null || mc.player == null) return;
      fake = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.nameUUIDFromBytes(("astral:" + name.text).getBytes()), name.text.isEmpty() ? "Steve" : name.text));
      fake.copyPositionAndRotation(mc.player); fake.setId(-4242); mc.world.addEntity(fake);
    }
    @Override public void onDisable(){ if (mc.world != null && fake != null) mc.world.removeEntity(-4242, Entity.RemovalReason.DISCARDED); fake = null; }
  }
  public static class Fog extends Module {
    public final Setting dist = add(Setting.num("Distance", 64, 8, 256));
    public Fog(){ super("Fog", Cat.VISUALS); }
  }
  public static class NoFog extends Module { public NoFog(){ super("No Fog", Cat.VISUALS); } }
  public static class SwingAnimation extends Module {
    public final Setting speed = add(Setting.num("Speed", 1, 0.3, 3)), angle = add(Setting.num("Angle", 40, 0, 120)), dir = add(Setting.mode("Direction", 0, "X", "Y", "Z")), strength = add(Setting.num("Strength", 1, 0, 2));
    public SwingAnimation(){ super("Swing Animation", Cat.VISUALS); }
  }

  // ================= GPS (always on when points exist) =================
  public static void renderGps(WorldRenderContext c, float td){
    var mc = MinecraftClient.getInstance(); if (Astral.GPS.isEmpty() || mc.player == null) return;
    Vec3d cam = c.camera().getPos(); Matrix4f m = RenderUtil.view(c); RenderUtil.begin(false);
    for (double[] g : Astral.GPS) { double d = new Vec3d(g[0], g[1], g[2]).distanceTo(cam); if (d > 150) continue;
      RenderUtil.box(m, new Box(g[0] + 0.42, g[1], g[2] + 0.42, g[0] + 0.58, g[1] + 30, g[2] + 0.58), 0x808B7CF6); }
    RenderUtil.end();
    for (int i = 0; i < Astral.GPS.size(); i++) {
      double[] g = Astral.GPS.get(i); Vec3d t = new Vec3d(g[0] + 0.5, g[1], g[2] + 0.5); double d = t.distanceTo(cam); Vec3d pos = t;
      if (d > 60) pos = cam.add(t.subtract(cam).normalize().multiply(60));
      RenderUtil.worldText(c, "GPS #" + (i + 1) + "  " + (int) d + "m", pos.x, pos.y + 2, pos.z, (float) Math.max(1.2, Math.min(d, 60) * 0.07), 0xFFB9A8FF, true);
    }
  }
}
