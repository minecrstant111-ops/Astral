package dev.astral;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
/** Drag HUD elements with the mouse while the chat is open. */
public final class HudDrag {
  static Module drag; static int ox, oy; static boolean prev;
  public static void render(DrawContext c, int mx, int my){
    for (Module m : Astral.MODULES) if (m.on && m.movable && m.x >= 0) c.drawBorder(m.x - 2, m.y - 2, m.w + 4, m.h + 4, m == drag ? 0xFFFFFFFF : 0xAA8B7CF6);
    boolean down = GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(), 0) == 1;
    if (down && !prev) { drag = null;
      for (int i = Astral.MODULES.size() - 1; i >= 0; i--) { Module m = Astral.MODULES.get(i);
        if (m.on && m.movable && m.x >= 0 && mx >= m.x - 2 && mx <= m.x + m.w + 2 && my >= m.y - 2 && my <= m.y + m.h + 2) { drag = m; ox = mx - m.x; oy = my - m.y; break; } } }
    if (down && drag != null) { drag.x = MathHelper.clamp(mx - ox, 0, Math.max(0, c.getScaledWindowWidth() - drag.w)); drag.y = MathHelper.clamp(my - oy, 0, Math.max(0, c.getScaledWindowHeight() - drag.h)); }
    if (!down) { if (drag != null) Config.save(); drag = null; }
    prev = down;
  }
}
