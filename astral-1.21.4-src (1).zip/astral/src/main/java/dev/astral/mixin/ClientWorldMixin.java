package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ClientWorld.class)
public class ClientWorldMixin {
  @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
  private void astral$sky(CallbackInfoReturnable<Object> cir){
    Mods2.CustomSky s = Astral.get(Mods2.CustomSky.class); if (s == null || !s.on || !s.useColor.b) return; int c = s.color.rgb();
    Object cur = cir.getReturnValue(); if (cur instanceof Integer) cir.setReturnValue(0xFF000000 | c); else if (cur instanceof Vec3d) cir.setReturnValue(new Vec3d((c >> 16 & 255) / 255.0, (c >> 8 & 255) / 255.0, (c & 255) / 255.0));
  }
}
