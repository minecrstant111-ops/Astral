package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.*;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ChatHud.class)
public class ChatHudMixin {
  @Inject(method = "render", at = @At("HEAD"))
  private void astral$in(DrawContext c, int tick, int mx, int my, boolean focused, CallbackInfo ci){
    Mods2.ChatAnimation t = Astral.get(Mods2.ChatAnimation.class); c.getMatrices().push();
    if (t != null && t.on) c.getMatrices().translate(0, t.offset(), 0);
  }
  @Inject(method = "render", at = @At("RETURN"))
  private void astral$out(DrawContext c, int tick, int mx, int my, boolean focused, CallbackInfo ci){ c.getMatrices().pop(); }
  @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V", at = @At("HEAD"))
  private void astral$msg(Text t, MessageSignatureData s, MessageIndicator i, CallbackInfo ci){ Mods2.ChatAnimation a = Astral.get(Mods2.ChatAnimation.class); if (a != null && a.on) a.newMsg(); }
}
