package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.render.BackgroundRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
  @ModifyVariable(method = "applyFog", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
  private static float astral$fog(float d){
    if (Astral.on(Mods2.NoFog.class)) return 100000f; Mods2.Fog f = Astral.get(Mods2.Fog.class); return f != null && f.on ? (float) f.dist.n : d;
  }
}
