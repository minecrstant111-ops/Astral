package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
  @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
  private void astral$label(CallbackInfoReturnable<Boolean> cir){ if (Astral.on(Mods2.Nametags.class)) cir.setReturnValue(false); }
}
