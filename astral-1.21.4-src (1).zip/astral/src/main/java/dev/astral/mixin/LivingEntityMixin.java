package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(LivingEntity.class)
public class LivingEntityMixin {
  @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true, require = 0)
  private void astral$swing(CallbackInfoReturnable<Integer> cir){
    if ((Object) this != MinecraftClient.getInstance().player) return; Mods2.SwingAnimation s = Astral.get(Mods2.SwingAnimation.class);
    if (s != null && s.on) cir.setReturnValue(Math.max(1, (int) Math.round(cir.getReturnValue() / s.speed.n)));
  }
}
