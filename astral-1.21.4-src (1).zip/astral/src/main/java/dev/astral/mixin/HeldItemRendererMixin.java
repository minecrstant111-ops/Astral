package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
  @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
  private void astral$in(AbstractClientPlayerEntity p, float td, float pitch, Hand hand, float swing, ItemStack item, float equip, MatrixStack m, VertexConsumerProvider vc, int light, CallbackInfo ci){
    Mods.ViewModel v = Astral.get(Mods.ViewModel.class); Mods2.SwingAnimation sa = Astral.get(Mods2.SwingAnimation.class); m.push();
    if (v != null && v.on) { m.translate(v.px.n, v.py.n, v.pz.n); float s = (float) v.scale.n; m.scale(s, s, s); }
    if (sa != null && sa.on && swing > 0) { float deg = (float) (sa.angle.n * sa.strength.n * Math.sin(swing * Math.PI));
      RotationAxis ax = sa.dir.mode == 1 ? RotationAxis.POSITIVE_Y : sa.dir.mode == 2 ? RotationAxis.POSITIVE_Z : RotationAxis.POSITIVE_X; m.multiply(ax.rotationDegrees(deg)); }
  }
  @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
  private void astral$out(AbstractClientPlayerEntity p, float td, float pitch, Hand hand, float swing, ItemStack item, float equip, MatrixStack m, VertexConsumerProvider vc, int light, CallbackInfo ci){ m.pop(); }
}
