package dev.astral;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;
public class RenderUtil {
  static Vec3d cam = Vec3d.ZERO;
  // ---- 2D ----
  public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int argb){
    r = Math.min(r, Math.min(w, h) / 2);
    for (int i = 0; i < r; i++) {
      double dy = r - i - 0.5; int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
      c.fill(x + inset, y + i, x + w - inset, y + i + 1, argb);
      c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, argb);
    }
    c.fill(x, y + r, x + w, y + h - r, argb);
  }
  public static int rainbow(double off){ return Setting.hsv((float) (((System.currentTimeMillis() / 4000.0) + off) % 1.0), 1f, 1f); }
  public static Text bold(String s){ return Text.literal(s).formatted(Formatting.BOLD); }
  public static void text(DrawContext c, String s, int x, int y, int col, boolean shadow){ c.drawText(MinecraftClient.getInstance().textRenderer, bold(s), x, y, col, shadow); }
  public static int tw(String s){ return MinecraftClient.getInstance().textRenderer.getWidth(bold(s)); }
  public static int lerpColor(int a, int b, double k){ k = Math.max(0, Math.min(1, k)); int r = 0;
    for (int sh = 0; sh <= 24; sh += 8) { int x = (a >> sh) & 255, y = (b >> sh) & 255; r |= ((int) (x + (y - x) * k) & 255) << sh; } return r; }
  // ---- 3D text / edges ----
  public static void worldText(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext c, String s, double x, double y, double z, float scale, int color, boolean bg){
    MinecraftClient mc = MinecraftClient.getInstance(); var cam = c.camera(); Vec3d cp = cam.getPos(); var ms = c.matrixStack();
    ms.push(); ms.translate(x - cp.x, y - cp.y, z - cp.z); ms.multiply(cam.getRotation()); float k = scale * 0.025f; ms.scale(-k, -k, k);
    Text t = bold(s); float w = -mc.textRenderer.getWidth(t) / 2f; var vc = mc.getBufferBuilders().getEntityVertexConsumers();
    mc.textRenderer.draw(t, w, 0, color, false, ms.peek().getPositionMatrix(), vc, net.minecraft.client.font.TextRenderer.TextLayerType.SEE_THROUGH, bg ? 0x66000000 : 0, 15728880);
    vc.draw(); ms.pop();
  }
  public static void edges(Matrix4f m, Box b, double t, int c){
    double[] xs = { b.minX, b.maxX }, ys = { b.minY, b.maxY }, zs = { b.minZ, b.maxZ };
    for (double y : ys) for (double z : zs) box(m, new Box(b.minX - t, y - t, z - t, b.maxX + t, y + t, z + t), c);
    for (double x : xs) for (double z : zs) box(m, new Box(x - t, b.minY - t, z - t, x + t, b.maxY + t, z + t), c);
    for (double x : xs) for (double y : ys) box(m, new Box(x - t, y - t, b.minZ - t, x + t, y + t, b.maxZ + t), c);
  }
  // ---- 3D ----
  public static Matrix4f view(WorldRenderContext c){ cam = c.camera().getPos(); return new Matrix4f(c.matrixStack().peek().getPositionMatrix()); }
  public static void begin(boolean depth){
    RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.disableCull();
    if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
    RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
  }
  public static void end(){ RenderSystem.enableDepthTest(); RenderSystem.enableCull(); RenderSystem.disableBlend(); }
  public static BufferBuilder qb(){ return Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR); }
  public static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int c){ b.vertex(m, (float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z)).color((c >> 16) & 255, (c >> 8) & 255, c & 255, (c >>> 24) & 255); }
  public static void flush(BufferBuilder b){ BuiltBuffer bb = b.endNullable(); if (bb != null) BufferRenderer.drawWithGlobalProgram(bb); }
  public static void quad(BufferBuilder b, Matrix4f m, double[] p1, double[] p2, double[] p3, double[] p4, int c){
    v(b, m, p1[0], p1[1], p1[2], c); v(b, m, p2[0], p2[1], p2[2], c); v(b, m, p3[0], p3[1], p3[2], c); v(b, m, p4[0], p4[1], p4[2], c);
  }
  public static void box(Matrix4f m, Box k, int c){
    BufferBuilder b = qb(); double a = k.minX, e = k.maxX, f = k.minY, g = k.maxY, h = k.minZ, i = k.maxZ;
    quad(b, m, new double[]{a,f,h}, new double[]{e,f,h}, new double[]{e,f,i}, new double[]{a,f,i}, c);
    quad(b, m, new double[]{a,g,h}, new double[]{a,g,i}, new double[]{e,g,i}, new double[]{e,g,h}, c);
    quad(b, m, new double[]{a,f,h}, new double[]{a,g,h}, new double[]{e,g,h}, new double[]{e,f,h}, c);
    quad(b, m, new double[]{a,f,i}, new double[]{e,f,i}, new double[]{e,g,i}, new double[]{a,g,i}, c);
    quad(b, m, new double[]{a,f,h}, new double[]{a,f,i}, new double[]{a,g,i}, new double[]{a,g,h}, c);
    quad(b, m, new double[]{e,f,h}, new double[]{e,g,h}, new double[]{e,g,i}, new double[]{e,f,i}, c);
    flush(b);
  }
  public static void ring(Matrix4f m, double cx, double cy, double cz, double r, double w, int seg, int c){
    BufferBuilder b = qb(); double r2 = r + w;
    for (int i = 0; i < seg; i++) {
      double a0 = Math.PI * 2 * i / seg, a1 = Math.PI * 2 * (i + 1) / seg;
      v(b, m, cx + Math.cos(a0) * r, cy, cz + Math.sin(a0) * r, c); v(b, m, cx + Math.cos(a0) * r2, cy, cz + Math.sin(a0) * r2, c);
      v(b, m, cx + Math.cos(a1) * r2, cy, cz + Math.sin(a1) * r2, c); v(b, m, cx + Math.cos(a1) * r, cy, cz + Math.sin(a1) * r, c);
    }
    flush(b);
  }
  public static void cone(Matrix4f m, double cx, double cy, double cz, double r, double hgt, int seg, int apex, int rim){
    BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
    v(b, m, cx, cy + hgt, cz, apex);
    for (int i = 0; i <= seg; i++) { double a = Math.PI * 2 * i / seg; v(b, m, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, rim); }
    flush(b);
  }
}
