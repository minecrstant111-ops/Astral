package dev.astral;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
/** Chat commands starting with a dot. */
public final class Commands {
  private Commands(){}
  static void msg(String s){
    var mc = MinecraftClient.getInstance(); if (mc.inGameHud == null) return;
    mc.inGameHud.getChatHud().addMessage(Text.literal("[Astral] ").formatted(Formatting.LIGHT_PURPLE).append(Text.literal(s).formatted(Formatting.WHITE)));
  }
  static String norm(String s){ return s.toLowerCase().replace(" ", "").replace("_", "").replace("-", ""); }
  static Module find(String n){
    String k = norm(n); for (Module m : Astral.MODULES) if (norm(m.name).equals(k)) return m;
    for (Module m : Astral.MODULES) if (norm(m.name).startsWith(k)) return m; return null;
  }
  public static boolean handle(String line){
    if (!line.startsWith(".")) return false;
    String[] a = line.substring(1).trim().split("\\s+");
    if (a[0].isEmpty()) { help(); return true; }
    switch (a[0].toLowerCase()) {
      case "gps" -> gps(a); case "bind" -> bind(a); case "friend" -> friend(a); case "config" -> config(a);
      default -> msg("Unknown command. Type . for the list.");
    }
    return true;
  }
  static void help(){
    msg("Functions:");
    for (Module.Cat c : Module.Cat.values()) { StringBuilder sb = new StringBuilder(c.label + ": ");
      for (Module m : Astral.MODULES) if (m.cat == c) sb.append(m.on ? "+" : "").append(m.name).append(", "); msg(sb.substring(0, sb.length() - 2)); }
    msg(".gps add <x y z> | clear | list");
    msg(".bind add <module> <key> | remove <module> | delete <module> | list");
    msg(".friend add|remove <nick> | list | clear");
    msg(".config save|load|delete <name> | list");
  }
  static void gps(String[] a){
    if (a.length < 2) { msg(".gps add <x y z> | clear | list"); return; }
    switch (a[1].toLowerCase()) {
      case "add" -> { try {
          double x, y, z; var p = MinecraftClient.getInstance().player;
          if (a.length >= 5) { x = Double.parseDouble(a[2]); y = Double.parseDouble(a[3]); z = Double.parseDouble(a[4]); }
          else if (a.length == 4) { x = Double.parseDouble(a[2]); z = Double.parseDouble(a[3]); y = p == null ? 64 : p.getY(); }
          else { msg("Usage: .gps add <x y z>"); return; }
          Astral.GPS.add(new double[]{ x, y, z }); Config.save(); msg("GPS #" + Astral.GPS.size() + " set: " + (int) x + " " + (int) y + " " + (int) z);
        } catch (NumberFormatException e) { msg("Coordinates must be numbers."); } }
      case "clear" -> { Astral.GPS.clear(); Config.save(); msg("All GPS points removed."); }
      case "list" -> { if (Astral.GPS.isEmpty()) msg("No GPS points."); var p = MinecraftClient.getInstance().player;
        for (int i = 0; i < Astral.GPS.size(); i++) { double[] g = Astral.GPS.get(i); String d = p == null ? "" : " (" + (int) Math.sqrt(p.squaredDistanceTo(g[0], g[1], g[2])) + "m)"; msg("#" + (i + 1) + ": " + (int) g[0] + " " + (int) g[1] + " " + (int) g[2] + d); } }
      default -> msg(".gps add <x y z> | clear | list");
    }
  }
  static int parseKey(String k){
    String s = k.toLowerCase();
    s = switch (s) { case "rshift" -> "right.shift"; case "lshift", "shift" -> "left.shift"; case "ctrl", "lctrl" -> "left.control"; case "rctrl" -> "right.control";
      case "alt", "lalt" -> "left.alt"; case "ralt" -> "right.alt"; case "esc" -> "escape"; case "del" -> "delete"; default -> s; };
    try { return InputUtil.fromTranslationKey("key.keyboard." + s).getCode(); } catch (Exception e) { return -1; }
  }
  static void bind(String[] a){
    if (a.length < 2) { msg(".bind add <module> <key> | remove <module> | list"); return; }
    switch (a[1].toLowerCase()) {
      case "add" -> { if (a.length < 4) { msg("Usage: .bind add <module> <key>"); return; }
        Module m = find(String.join(" ", Arrays.copyOfRange(a, 2, a.length - 1))); int k = parseKey(a[a.length - 1]);
        if (m == null) { msg("Module not found."); return; } if (k < 0) { msg("Unknown key."); return; }
        m.key = k; Config.save(); msg(m.name + " bound to " + Astral.keyName(k)); }
      case "remove", "delete" -> { if (a.length < 3) { msg("Usage: .bind remove <module>"); return; }
        Module m = find(String.join(" ", Arrays.copyOfRange(a, 2, a.length))); if (m == null) { msg("Module not found."); return; }
        m.key = -1; Config.save(); msg("Bind removed from " + m.name); }
      case "list" -> { boolean any = false; for (Module m : Astral.MODULES) if (m.key >= 0) { msg(m.name + " [" + Astral.keyName(m.key) + "]"); any = true; } if (!any) msg("No binds."); }
      default -> msg(".bind add <module> <key> | remove <module> | list");
    }
  }
  static void friend(String[] a){
    if (a.length < 2) { msg(".friend add|remove <nick> | list | clear"); return; }
    switch (a[1].toLowerCase()) {
      case "add" -> { if (a.length < 3) { msg("Usage: .friend add <nick>"); return; } Astral.FRIENDS.add(a[2].toLowerCase()); Config.save(); msg("Friend added: " + a[2]); }
      case "remove" -> { if (a.length < 3) { msg("Usage: .friend remove <nick>"); return; } msg(Astral.FRIENDS.remove(a[2].toLowerCase()) ? "Friend removed: " + a[2] : "Not in the list."); Config.save(); }
      case "list" -> msg(Astral.FRIENDS.isEmpty() ? "No friends." : "Friends: " + String.join(", ", Astral.FRIENDS));
      case "clear" -> { Astral.FRIENDS.clear(); Config.save(); msg("Friend list cleared."); }
      default -> msg(".friend add|remove <nick> | list | clear");
    }
  }
  static void config(String[] a){
    if (a.length < 2) { msg(".config save|load|delete <name> | list"); return; }
    String n = a.length > 2 ? a[2].replaceAll("[^A-Za-z0-9_\\-]", "") : "";
    switch (a[1].toLowerCase()) {
      case "save" -> { if (n.isEmpty()) { msg("Usage: .config save <name>"); return; } Config.saveNamed(n); msg("Config saved: " + n); }
      case "load" -> { if (n.isEmpty()) { msg("Usage: .config load <name>"); return; } msg(Config.loadNamed(n) ? "Config loaded: " + n : "Config not found."); }
      case "delete" -> { if (n.isEmpty()) { msg("Usage: .config delete <name>"); return; } msg(Config.delete(n) ? "Config deleted: " + n : "Config not found."); }
      case "list" -> { List<String> l = Config.names(); msg(l.isEmpty() ? "No configs." : "Configs: " + String.join(", ", l)); }
      default -> msg(".config save|load|delete <name> | list");
    }
  }
}
