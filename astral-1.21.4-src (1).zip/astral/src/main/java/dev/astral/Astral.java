package dev.astral;
import java.util.*;
import dev.astral.gui.ClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
public class Astral implements ClientModInitializer {
  public static final List<Module> MODULES = new ArrayList<>();
  static final Map<Class<?>, Module> BY = new HashMap<>();
  public static final Set<String> FRIENDS = new TreeSet<>();
  public static final List<double[]> GPS = new ArrayList<>();
  public static KeyBinding guiKey, zoomKey; public static LivingEntity target; public static long targetTime;
  public static int combo; public static long lastHit; public static boolean lastCrit; static boolean booted;
  static void reg(Module m, Module.Cat c){ if (c != null) m.cat = c; MODULES.add(m); BY.put(m.getClass(), m); }
  static void reg(Module m){ reg(m, null); }
  @SuppressWarnings("unchecked") public static <T extends Module> T get(Class<T> c){ return (T) BY.get(c); }
  public static boolean on(Class<? extends Module> c){ Module m = BY.get(c); return m != null && m.on; }
  public static boolean isFriend(String n){ return FRIENDS.contains(n.toLowerCase()); }
  public static String keyName(int code){ try { return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString().toUpperCase(); } catch (Throwable t) { return "KEY" + code; } }

  @Override public void onInitializeClient(){
    // ---- Combat ----
    reg(new Mods.TargetESP(), Module.Cat.COMBAT); reg(new Mods2.Nametags()); reg(new Mods2.HitEffect()); reg(new Mods2.DamageNumbers()); reg(new Mods.HitColor(), Module.Cat.COMBAT);
    // ---- Visuals ----
    reg(new Mods.Trails()); reg(new Mods2.Halo()); reg(new Mods2.WorldEffects()); reg(new Mods2.CustomSky()); reg(new Mods.Crosshair()); reg(new Mods2.CustomBlockOutline());
    reg(new Mods2.FovChanger()); reg(new Mods2.Trajectory()); reg(new Mods.Fullbright()); reg(new Mods2.TntTimer()); reg(new Mods.NameChanger()); reg(new Mods2.FakePlayer());
    reg(new Mods.NoHurtCam()); reg(new Mods2.Fog()); reg(new Mods2.SwingAnimation()); reg(new Mods2.NoFog());
    reg(new Mods.AspectRatio()); reg(new Mods.ChinaHat()); reg(new Mods.JumpCircles()); reg(new Mods.HitboxCustomizer()); reg(new Mods.ViewModel());
    reg(new Mods.ItemPhysic()); reg(new Mods.Weather()); reg(new Mods.Zoom()); reg(new Mods.NoOverlay());
    // ---- Utils ----
    reg(new Mods2.TabAnimation()); reg(new Mods2.ChatAnimation()); reg(new Mods2.AuctionHelper());
    reg(new UtilMods.AutoSprint()); reg(new UtilMods.AutoRespawn()); reg(new UtilMods.ItemScroller()); reg(new UtilMods.ToggleSneak());
    // ---- HUD ----
    reg(new HudMods.Hud()); reg(new HudMods.InfoHud()); reg(new HudMods.ArmorHud()); reg(new HudMods.TargetHud()); reg(new HudMods.PotionHud());
    reg(new HudMods.CooldownsHud()); reg(new HudMods.KeybindHud()); reg(new HudMods.Keystrokes()); reg(new HudMods.Cps()); reg(new HudMods.HitCounter());
    Config.load();
    guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.astral.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.misc"));
    zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.astral.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.misc"));
    ClientTickEvents.END_CLIENT_TICK.register(mc -> {
      if (!booted && mc.options != null) { booted = true; for (Module m : MODULES) if (m.on) m.onEnable(); }
      while (guiKey.wasPressed()) mc.setScreen(new ClickGui());
      if (mc.currentScreen == null && mc.player != null) for (Module m : MODULES) if (m.key >= 0 && !(m instanceof Mods2.TabAnimation)) {
        boolean d = InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.key); if (d && !m.keyDown) m.toggle(); m.keyDown = d; }
      for (Module m : MODULES) if (m.on) m.tick();
    });
    HudRenderCallback.EVENT.register((ctx, tc) -> { float td = tc.getTickDelta(true); for (Module m : MODULES) if (m.on) m.hud(ctx, td); });
    WorldRenderEvents.LAST.register(ctx -> { float td = ctx.tickCounter().getTickDelta(true); for (Module m : MODULES) if (m.on) m.world(ctx, td); Mods2.renderGps(ctx, td); });
    WorldRenderEvents.BLOCK_OUTLINE.register((wrc, boc) -> !on(Mods2.CustomBlockOutline.class));
    AttackEntityCallback.EVENT.register((p, w, hand, e, hit) -> {
      if (w.isClient && e instanceof LivingEntity le) {
        if (le instanceof PlayerEntity pe && isFriend(pe.getName().getString())) return ActionResult.PASS;
        target = le; targetTime = System.currentTimeMillis(); combo++; lastHit = targetTime;
        lastCrit = p.fallDistance > 0 && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater();
        Mods2.HitEffect he = get(Mods2.HitEffect.class); if (he != null && he.on) he.spawn(le);
      }
      return ActionResult.PASS; });
    ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !Commands.handle(msg));
    ScreenEvents.AFTER_INIT.register((c, screen, sw, sh) -> {
      if (screen instanceof ChatScreen) ScreenEvents.afterRender(screen).register((s, ctx, mx, my, td) -> HudDrag.render(ctx, mx, my));
      if (screen instanceof HandledScreen<?> hs) {
        ScreenEvents.afterTick(screen).register(s -> UtilMods.ItemScroller.scroll(hs));
        ScreenEvents.afterRender(screen).register((s, ctx, mx, my, td) -> Mods2.AuctionHelper.render(hs, ctx)); }
    });
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> { Config.save(); for (Module m : MODULES) if (m.on) m.onDisable(); });
  }
}
