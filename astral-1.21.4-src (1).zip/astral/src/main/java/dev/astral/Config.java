package dev.astral;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
public class Config {
  static final Gson G = new GsonBuilder().setPrettyPrinting().create();
  static Path main(){ return FabricLoader.getInstance().getConfigDir().resolve("astral.json"); }
  static Path dir(){ Path p = FabricLoader.getInstance().getConfigDir().resolve("astral-configs"); try { Files.createDirectories(p); } catch (Exception ignored) {} return p; }
  public static void save(){ write(main(), true); }
  public static void load(){ read(main(), true, false); }
  public static void saveNamed(String n){ write(dir().resolve(n + ".json"), false); }
  public static boolean loadNamed(String n){ Path p = dir().resolve(n + ".json"); if (!Files.exists(p)) return false; read(p, false, true); return true; }
  public static boolean delete(String n){ try { return Files.deleteIfExists(dir().resolve(n + ".json")); } catch (Exception e) { return false; } }
  public static List<String> names(){
    List<String> r = new ArrayList<>();
    try (var s = Files.list(dir())) { s.forEach(f -> { String n = f.getFileName().toString(); if (n.endsWith(".json")) r.add(n.substring(0, n.length() - 5)); }); } catch (Exception ignored) {}
    Collections.sort(r); return r;
  }
  static void write(Path path, boolean all){
    try {
      JsonObject root = new JsonObject();
      for (Module m : Astral.MODULES) {
        JsonObject o = new JsonObject(); o.addProperty("on", m.on); o.addProperty("x", m.x); o.addProperty("y", m.y); o.addProperty("key", m.key);
        for (Setting s : m.settings) switch (s.type) {
          case BOOL -> o.addProperty(s.name, s.b); case NUM, COLOR -> o.addProperty(s.name, s.n);
          case MODE -> o.addProperty(s.name, s.mode); case TEXT -> o.addProperty(s.name, s.text); }
        root.add(m.name, o);
      }
      if (all) {
        JsonArray f = new JsonArray(); for (String n : Astral.FRIENDS) f.add(n); root.add("@friends", f);
        JsonArray g = new JsonArray(); for (double[] p : Astral.GPS) { JsonArray a = new JsonArray(); for (double d : p) a.add(d); g.add(a); } root.add("@gps", g);
      }
      Files.writeString(path, G.toJson(root));
    } catch (Exception e) { e.printStackTrace(); }
  }
  static void read(Path path, boolean all, boolean live){
    try {
      if (!Files.exists(path)) return;
      JsonObject root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
      for (Module m : Astral.MODULES) {
        if (!root.has(m.name)) continue; JsonObject o = root.getAsJsonObject(m.name);
        if (o.has("on")) { boolean nw = o.get("on").getAsBoolean(); if (live && nw != m.on) m.toggle(); else m.on = nw; }
        if (o.has("x")) m.x = o.get("x").getAsInt(); if (o.has("y")) m.y = o.get("y").getAsInt(); if (o.has("key")) m.key = o.get("key").getAsInt();
        for (Setting s : m.settings) { if (!o.has(s.name)) continue; JsonElement e = o.get(s.name);
          switch (s.type) { case BOOL -> s.b = e.getAsBoolean(); case NUM, COLOR -> s.n = e.getAsDouble();
            case MODE -> s.mode = Math.min(e.getAsInt(), s.modes.length - 1); case TEXT -> s.text = e.getAsString(); } }
      }
      if (all) {
        Astral.FRIENDS.clear(); if (root.has("@friends")) for (JsonElement e : root.getAsJsonArray("@friends")) Astral.FRIENDS.add(e.getAsString());
        Astral.GPS.clear(); if (root.has("@gps")) for (JsonElement e : root.getAsJsonArray("@gps")) { JsonArray a = e.getAsJsonArray(); Astral.GPS.add(new double[]{ a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble() }); }
      }
    } catch (Exception e) { e.printStackTrace(); }
  }
}
