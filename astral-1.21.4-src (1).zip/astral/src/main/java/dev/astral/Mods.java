package dev.astral;
import java.util.*;
import dev.astral.mixin.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

public final class Mods {
  private Mods(){}
  static double ease(double p, double smooth){ return 1 - Math.pow(1 - MathHelper.clamp(p, 0, 1), 1 + smooth * 3); }
  static Vec3d lerp(Entity e, float td){ return new Vec3d(MathHelper.lerp(td, e.prevX, e.getX()), MathHelper.lerp(td, e.prevY, e.getY()), MathHelper.lerp(td, e.prevZ, e.getZ())); }
  static int col(Setting hue, Setting rainbow, double off){ return rainbow != null && rainbow.b ? RenderUtil.rainbow(off) : hue.rgb(); }
  static int argb(double a, int rgb){ return ((int) (MathHelper.clamp(a, 0, 1) * 255) << 24) | (rgb & 0xFFFFFF); }

  // ================= Aspect Ratio =================
  public static class AspectRatio extends Module {
    final Setting preset = add(Setting.mode("Preset", 0, "Default", "4:3", "5:4", "16:10", "21:9", "1:1", "Custom"));
    final Setting custom = add(Setting.num("Custom", 1.78, 0.5, 3.5));
    public AspectRatio(){ super("Aspect Ratio", Cat.VISUALS); }
    public double ratio(){ return switch (preset.mode) { case 1 -> 4 / 3.0; case 2 -> 5 / 4.0; case 3 -> 16 / 10.0; case 4 -> 21 / 9.0; case 5 -> 1.0; case 6 -> custom.n; default -> -1; }; }
  }

  // ================= TAnimations =================
  public static class TAnimations extends Module {
    final Setting tab = add(Setting.bool("Tab", true)), tabSpeed = add(Setting.num("Tab speed", 1, 0.3, 3)), tabSmooth = add(Setting.num("Tab smooth", 0.5, 0, 1));
    final Setting chat = add(Setting.bool("Chat", true)), chatSpeed = add(Setting.num("Chat speed", 1, 0.3, 3)), chatSmooth = add(Setting.num("Chat smooth", 0.5, 0, 1));
    float tabP, chatOff; long last = System.nanoTime(), lastChat = System.nanoTime();
    public TAnimations(){ super("TAnimations", Cat.VISUALS); }
    @Override public void tick(){ if (!mc.options.playerListKey.isPressed()) { tabP = 0; last = System.nanoTime(); } }
    public float tabOffset(){
      if (!tab.b) return 0; long now = System.nanoTime(); float dt = (now - last) / 1e9f; last = now;
      tabP = Math.min(1, tabP + dt * (float) tabSpeed.n * 3);
      return -(float) ((1 - ease(tabP, tabSmooth.n)) * 70);
    }
    public void chatNew(){ if (chat.b) chatOff = 9; }
    public float chatOffset(){
      long now = System.nanoTime(); float dt = (now - lastChat) / 1e9f; lastChat = now;
      chatOff *= (float) Math.exp(-dt * chatSpeed.n * (4 + 10 * (1 - chatSmooth.n)));
      return chat.b ? chatOff : 0;
    }
  }

  // ================= Block Overlay =================
  public static class BlockOverlay extends Module {
    final Setting color = add(Setting.color("Color", 0.75)), alpha = add(Setting.num("Alpha", 0.35, 0.05, 1));
    public BlockOverlay(){ super("Block Overlay", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.world == null || !(mc.crosshairTarget instanceof BlockHitResult h) || h.getType() != HitResult.Type.BLOCK) return;
      BlockPos p = h.getBlockPos(); VoxelShape sh = mc.world.getBlockState(p).getOutlineShape(mc.world, p); if (sh.isEmpty()) return;
      Box b = sh.getBoundingBox().offset(p).expand(0.002);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true); RenderUtil.box(m, b, argb(alpha.n, color.rgb())); RenderUtil.end();
    }
  }

  // ================= China Hat / Nimb =================
  public static class ChinaHat extends Module {
    final Setting color = add(Setting.color("Color", 0.0)), rainbow = add(Setting.bool("Rainbow", true)), alpha = add(Setting.num("Alpha", 0.55, 0.1, 1));
    final Setting radius = add(Setting.num("Radius", 0.6, 0.3, 1)), height = add(Setting.num("Height", 0.35, 0.1, 0.8));
    public ChinaHat(){ super("China Hat", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.player == null || !c.camera().isThirdPerson()) return;
      Vec3d p = lerp(mc.player, td); double top = p.y + mc.player.getHeight() - 0.03; int rgb = col(color, rainbow, 0);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(false);
      RenderUtil.cone(m, p.x, top, p.z, radius.n, height.n, 48, argb(alpha.n, rgb), argb(alpha.n * 0.55, rgb));
      RenderUtil.ring(m, p.x, top, p.z, radius.n - 0.02, 0.03, 48, argb(0.95, rgb)); RenderUtil.end();
    }
  }
  public static class Nimb extends Module {
    final Setting color = add(Setting.color("Color", 0.12)), rainbow = add(Setting.bool("Rainbow", false)), radius = add(Setting.num("Radius", 0.32, 0.15, 0.8)), thick = add(Setting.num("Thickness", 0.05, 0.02, 0.2));
    public Nimb(){ super("Nimb", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      if (mc.player == null || !c.camera().isThirdPerson()) return;
      Vec3d p = lerp(mc.player, td); double y = p.y + mc.player.getHeight() + 0.22 + Math.sin(System.currentTimeMillis() / 500.0) * 0.02; int rgb = col(color, rainbow, 0);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(false);
      RenderUtil.ring(m, p.x, y, p.z, radius.n - thick.n, thick.n * 3, 48, argb(0.18, rgb));
      RenderUtil.ring(m, p.x, y, p.z, radius.n, thick.n, 48, argb(0.95, rgb)); RenderUtil.end();
    }
  }

  // ================= Crosshair =================
  public static class Crosshair extends Module {
    final Setting style = add(Setting.mode("Style", 0, "Cross", "Circle", "Dot", "Square")), dynamic = add(Setting.bool("Dynamic", true)), color = add(Setting.color("Color", 0.5));
    final Setting size = add(Setting.num("Size", 5, 1, 14)), gap = add(Setting.num("Gap", 3, 0, 10)), thick = add(Setting.num("Thickness", 1, 1, 4));
    float cur;
    public Crosshair(){ super("Custom Crosshair", Cat.VISUALS); }
    public void draw(DrawContext c){
      int cx = c.getScaledWindowWidth() / 2, cy = c.getScaledWindowHeight() / 2; var p = mc.player;
      double sp = Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ);
      float tg = (float) (gap.n + (dynamic.b ? sp * 18 + (1 - p.getAttackCooldownProgress(0)) * 3 : 0)); cur += (tg - cur) * 0.2f;
      int col = 0xFF000000 | color.rgb(), t = (int) thick.n, len = (int) size.n, g = Math.round(cur), ht = t / 2;
      switch (style.mode) {
        case 0 -> { c.fill(cx - g - len, cy - ht, cx - g, cy - ht + t, col); c.fill(cx + g, cy - ht, cx + g + len, cy - ht + t, col);
                    c.fill(cx - ht, cy - g - len, cx - ht + t, cy - g, col); c.fill(cx - ht, cy + g, cx - ht + t, cy + g + len, col); }
        case 1 -> { double r = g + len; for (int i = 0; i < 48; i++) { double a = Math.PI * 2 * i / 48; int px = (int) Math.round(cx + Math.cos(a) * r), py = (int) Math.round(cy + Math.sin(a) * r); c.fill(px - ht, py - ht, px - ht + t, py - ht + t, col); } }
        case 2 -> { int d = Math.max(t, 2); c.fill(cx - d / 2, cy - d / 2, cx - d / 2 + d, cy - d / 2 + d, col); }
        default -> { int r = g + len; c.drawBorder(cx - r, cy - r, r * 2 + 1, r * 2 + 1, col); }
      }
    }
  }

  // ================= Fullbright / NoOverlay / NoHurtCam =================
  public static class Fullbright extends Module {
    Object old;
    public Fullbright(){ super("Fullbright", Cat.VISUALS); }
    void set(Object v){ ((SimpleOptionAccessor) (Object) mc.options.getGamma()).astral$setValue(v); }
    @Override public void onEnable(){ Object o = mc.options.getGamma().getValue(); old = (o instanceof Double d && d > 1) ? (Object) 1.0 : o; }
    @Override public void tick(){ set(15.0); }
    @Override public void onDisable(){ if (old != null) set(old); }
  }
  public static class NoOverlay extends Module {
    public final Setting fire = add(Setting.bool("Fire", true)), water = add(Setting.bool("Water", true)), wall = add(Setting.bool("In wall", true));
    public NoOverlay(){ super("No Overlay", Cat.VISUALS); }
  }
  public static class NoHurtCam extends Module { public NoHurtCam(){ super("No Hurt Cam", Cat.VISUALS); } }

  // ================= Hit Color =================
  public static class HitColor extends Module {
    final Setting color = add(Setting.color("Color", 0.6)), alpha = add(Setting.num("Alpha", 0.7, 0.1, 1));
    int applied = 0;
    public HitColor(){ super("Hit Color", Cat.VISUALS); }
    void apply(int argb){
      try { NativeImageBackedTexture t = ((OverlayTextureAccessor) mc.gameRenderer.getOverlayTexture()).astral$getTexture(); NativeImage img = t.getImage();
        if (img == null) return; for (int yy = 0; yy < 8; yy++) for (int xx = 0; xx < 16; xx++) img.setColorArgb(xx, yy, argb); t.upload(); applied = argb; } catch (Throwable ignored) {}
    }
    @Override public void tick(){ int a = argb(alpha.n, color.rgb()); if (a != applied) apply(a); }
    @Override public void onDisable(){ apply(0xB2FF0000); }
  }

  // ================= Item Physic =================
  public static class ItemPhysic extends Module { public ItemPhysic(){ super("Item Physic", Cat.VISUALS); } }

  // ================= Hitbox Customizer =================
  public static class HitboxCustomizer extends Module {
    public final Setting color = add(Setting.color("Color", 0.8)), rainbow = add(Setting.bool("Rainbow", false)), eye = add(Setting.bool("Eye line", false));
    public HitboxCustomizer(){ super("Hitbox Customizer", Cat.VISUALS); }
    public float[] rgb(){ int c = col(color, rainbow, 0); return new float[]{ (c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f }; }
    @Override public void tick(){ mc.getEntityRenderDispatcher().setRenderHitboxes(true); }
    @Override public void onDisable(){ mc.getEntityRenderDispatcher().setRenderHitboxes(false); }
  }

  // ================= Jump Circles =================
  public static class JumpCircles extends Module {
    final Setting color = add(Setting.color("Color", 0.55)), rainbow = add(Setting.bool("Rainbow", false)), speed = add(Setting.num("Speed", 1, 0.3, 3));
    final Setting smooth = add(Setting.num("Smooth", 0.5, 0, 1)), thick = add(Setting.num("Thickness", 0.08, 0.02, 0.3)), size = add(Setting.num("Size", 1.4, 0.5, 3));
    final List<double[]> list = new ArrayList<>(); boolean wasGround;
    public JumpCircles(){ super("Jump Circles", Cat.VISUALS); }
    @Override public void tick(){
      var p = mc.player; if (p == null) return; boolean g = p.isOnGround();
      if (wasGround && !g && p.getVelocity().y > 0.1) list.add(new double[]{ p.getX(), p.getY() + 0.02, p.getZ(), System.nanoTime() });
      wasGround = g; long now = System.nanoTime(); list.removeIf(c -> (now - c[3]) / 1e9 > 1.0 / speed.n);
    }
    @Override public void world(WorldRenderContext c, float td){
      if (list.isEmpty()) return; long now = System.nanoTime(); Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true);
      for (double[] k : list) { double t = (now - k[3]) / 1e9 * speed.n; double r = size.n * ease(t, smooth.n);
        RenderUtil.ring(m, k[0], k[1], k[2], r, thick.n, 48, argb(t < 0.5 ? 1 : (1 - t) * 2, col(color, rainbow, t))); }
      RenderUtil.end();
    }
  }

  // ================= Target ESP =================
  public static class TargetESP extends Module {
    final Setting style = add(Setting.mode("Style", 0, "Circle", "Cross", "Diamond")), color = add(Setting.color("Color", 0.75)), rainbow = add(Setting.bool("Rainbow", false)), size = add(Setting.num("Size", 1, 0.5, 2));
    public TargetESP(){ super("Target ESP", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      LivingEntity e = Astral.target; long now = System.currentTimeMillis();
      if (e == null || e.isRemoved() || !e.isAlive() || now - Astral.targetTime > 6000) return;
      Vec3d p = lerp(e, td); int rgb = col(color, rainbow, 0); double t = now / 1000.0; Matrix4f m = RenderUtil.view(c); RenderUtil.begin(false);
      double s = size.n;
      switch (style.mode) {
        case 0 -> { double r = e.getWidth() * 0.9 * s; for (int i = 0; i < 4; i++) { double k = ((Math.sin(t * 2.5 - i * 0.25) + 1) / 2); RenderUtil.ring(m, p.x, p.y + k * e.getHeight(), p.z, r, 0.05, 40, argb(1 - i * 0.28, rgb)); } }
        case 1 -> { double cy = p.y + e.getHeight() / 2, hs = 0.45 * s; for (int i = 0; i < 2; i++) { double a = t * 1.5 + i * Math.PI / 2, dx = Math.cos(a) * hs, dz = Math.sin(a) * hs; BufferBuilder b = RenderUtil.qb();
            RenderUtil.quad(b, m, new double[]{p.x - dx, cy - 0.4 * s, p.z - dz}, new double[]{p.x + dx, cy - 0.4 * s, p.z + dz}, new double[]{p.x + dx, cy + 0.4 * s, p.z + dz}, new double[]{p.x - dx, cy + 0.4 * s, p.z - dz}, argb(0.55, rgb)); RenderUtil.flush(b); } }
        default -> { double cy = p.y + e.getHeight() + 0.45 + Math.sin(t * 3) * 0.05, r = 0.16 * s, hh = 0.24 * s, a = t * 2; BufferBuilder b = RenderUtil.qb();
            for (int i = 0; i < 4; i++) { double a0 = a + i * Math.PI / 2, a1 = a0 + Math.PI / 2; double[] q0 = {p.x + Math.cos(a0) * r, cy, p.z + Math.sin(a0) * r}, q1 = {p.x + Math.cos(a1) * r, cy, p.z + Math.sin(a1) * r};
              RenderUtil.quad(b, m, new double[]{p.x, cy + hh, p.z}, q0, q1, q1, argb(0.8, rgb)); RenderUtil.quad(b, m, new double[]{p.x, cy - hh, p.z}, q1, q0, q0, argb(0.55, rgb)); } RenderUtil.flush(b); }
      }
      RenderUtil.end();
    }
  }

  // ================= Trails =================
  public static class Trails extends Module {
    final Setting color = add(Setting.color("Color", 0.9)), rainbow = add(Setting.bool("Rainbow", true)), life = add(Setting.num("Length (s)", 1.2, 0.3, 4)), height = add(Setting.num("Thickness", 0.25, 0.05, 1.8)), particles = add(Setting.bool("Particles", false));
    final ArrayDeque<double[]> pts = new ArrayDeque<>();
    public Trails(){ super("Trail", Cat.VISUALS); }
    @Override public void tick(){
      var p = mc.player; if (p == null) return; long now = System.nanoTime();
      if (particles.b && mc.world != null) mc.world.addParticle(net.minecraft.particle.ParticleTypes.END_ROD, p.getX(), p.getY() + 0.2, p.getZ(), 0, 0, 0);
      double[] l = pts.peekLast(); if (l == null || Math.hypot(p.getX() - l[0], p.getZ() - l[2]) > 0.05 || Math.abs(p.getY() - l[1]) > 0.05) pts.add(new double[]{ p.getX(), p.getY() + 0.05, p.getZ(), now });
      while (!pts.isEmpty() && (now - pts.peekFirst()[3]) / 1e9 > life.n) pts.pollFirst();
    }
    @Override public void world(WorldRenderContext c, float td){
      if (pts.size() < 2) return; Matrix4f m = RenderUtil.view(c); RenderUtil.begin(false); BufferBuilder b = RenderUtil.qb(); long now = System.nanoTime(); double[] a = null; int i = 0;
      for (double[] q : pts) { if (a != null) { int rgb = col(color, rainbow, i * 0.01); int ca = argb(1 - (now - a[3]) / 1e9 / life.n, rgb) , cb = argb(1 - (now - q[3]) / 1e9 / life.n, rgb);
          RenderUtil.v(b, m, a[0], a[1], a[2], ca); RenderUtil.v(b, m, a[0], a[1] + height.n, a[2], ca); RenderUtil.v(b, m, q[0], q[1] + height.n, q[2], cb); RenderUtil.v(b, m, q[0], q[1], q[2], cb); }
        a = q; i++; }
      RenderUtil.flush(b); RenderUtil.end();
    }
  }

  // ================= View Model =================
  public static class ViewModel extends Module {
    public final Setting px = add(Setting.num("X", 0, -1.5, 1.5)), py = add(Setting.num("Y", 0, -1.5, 1.5)), pz = add(Setting.num("Z", 0, -1.5, 1.5)), scale = add(Setting.num("Scale", 1, 0.3, 1.8));
    public ViewModel(){ super("View Model", Cat.VISUALS); }
  }

  // ================= Trajectory =================
  public static class Trajectory extends Module {
    final Setting color = add(Setting.color("Color", 0.45));
    public Trajectory(){ super("Trajectory", Cat.VISUALS); }
    @Override public void world(WorldRenderContext c, float td){
      var pl = mc.player; if (pl == null || mc.world == null) return;
      double speed = 0, grav = 0.03, pitchOff = 0; ItemStack st = pl.getMainHandStack(); Item it = st.getItem();
      if (!(it instanceof BowItem || it instanceof CrossbowItem || it instanceof TridentItem || it instanceof EnderPearlItem || it instanceof SnowballItem || it instanceof EggItem || it instanceof ThrowablePotionItem || it instanceof ExperienceBottleItem)) { st = pl.getOffHandStack(); it = st.getItem(); }
      if (it instanceof BowItem) { if (!pl.isUsingItem()) return; float pull = BowItem.getPullProgress(pl.getItemUseTime()); if (pull < 0.1f) return; speed = pull * 3; grav = 0.05; }
      else if (it instanceof CrossbowItem) { if (!CrossbowItem.isCharged(st)) return; speed = 3.15; grav = 0.05; }
      else if (it instanceof TridentItem) { if (!pl.isUsingItem()) return; speed = 2.5; grav = 0.05; }
      else if (it instanceof ThrowablePotionItem) { speed = 0.5; grav = 0.05; pitchOff = -20; }
      else if (it instanceof ExperienceBottleItem) { speed = 0.7; grav = 0.07; pitchOff = -20; }
      else if (it instanceof EnderPearlItem || it instanceof SnowballItem || it instanceof EggItem) speed = 1.5; else return;
      double yaw = Math.toRadians(pl.getYaw()), pit = Math.toRadians(pl.getPitch() + pitchOff);
      Vec3d pos = pl.getCameraPosVec(td).add(-Math.cos(yaw) * 0.16, -0.1, -Math.sin(yaw) * 0.16);
      Vec3d vel = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit)).multiply(speed);
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true); com.mojang.blaze3d.systems.RenderSystem.lineWidth(2.5f);
      BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR); int col = 0xFF000000 | color.rgb(); Vec3d end = null;
      RenderUtil.v(b, m, pos.x, pos.y, pos.z, col);
      for (int i = 0; i < 120; i++) {
        Vec3d next = pos.add(vel); BlockHitResult hr = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, pl));
        if (hr.getType() != HitResult.Type.MISS) { end = hr.getPos(); RenderUtil.v(b, m, end.x, end.y, end.z, col); break; }
        pos = next; vel = vel.multiply(0.99).add(0, -grav, 0); RenderUtil.v(b, m, pos.x, pos.y, pos.z, col);
      }
      RenderUtil.flush(b);
      com.mojang.blaze3d.systems.RenderSystem.lineWidth(1f);
      if (end != null) RenderUtil.ring(m, end.x, end.y + 0.02, end.z, 0.12, 0.05, 16, argb(0.9, color.rgb()));
      RenderUtil.end();
    }
  }

  // ================= Name Changer =================
  public static class NameChanger extends Module {
    final Setting name = add(Setting.text("Name", "Astral")); String real;
    public NameChanger(){ super("Name Changer", Cat.VISUALS); }
    public String replace(String s){
      if (real == null) real = mc.getSession().getUsername(); if (name.text.isEmpty() || !s.contains(real)) return s; return s.replace(real, name.text);
    }
  }

  // ================= Zoom =================
  public static class Zoom extends Module {
    final Setting fov = add(Setting.num("Zoom FOV", 20, 5, 60)), smooth = add(Setting.bool("Smooth", true));
    Integer old; boolean active; double cur;
    public Zoom(){ super("Zoom", Cat.VISUALS); }
    void set(int v){ ((SimpleOptionAccessor) (Object) mc.options.getFov()).astral$setValue(Integer.valueOf(v)); }
    @Override public void tick(){
      boolean pressed = Astral.zoomKey != null && Astral.zoomKey.isPressed() && mc.currentScreen == null;
      if (pressed && !active) { old = mc.options.getFov().getValue(); cur = old; active = true; }
      if (!active) return;
      double target = pressed ? fov.n : old; cur += (target - cur) * (smooth.b ? 0.35 : 1); set((int) Math.round(cur));
      if (!pressed && Math.abs(cur - old) < 1) { set(old); active = false; }
    }
    @Override public void onDisable(){ if (active && old != null) { set(old); active = false; } }
  }
  // ================= Time Changer / Weather =================
  public static class TimeChanger extends Module {
    final Setting time = add(Setting.num("Time (h)", 12, 0, 24));
    public TimeChanger(){ super("Time Changer", Cat.VISUALS); }
    @Override public void tick(){ if (mc.world != null) mc.world.getLevelProperties().setTimeOfDay((long) (((time.n - 6 + 24) % 24) * 1000)); }
  }
  public static class Weather extends Module {
    final Setting mode = add(Setting.mode("Weather", 0, "Clear", "Rain", "Thunder"));
    public Weather(){ super("Weather", Cat.VISUALS); }
    @Override public void tick(){ if (mc.world == null) return; mc.world.setRainGradient(mode.mode == 0 ? 0f : 1f); mc.world.setThunderGradient(mode.mode == 2 ? 1f : 0f); }
  }
  // ================= Hit Particles / Hit Waves =================
  public static class HitParticles extends Module {
    final Setting style = add(Setting.mode("Style", 0, "Crit", "Magic", "Heart", "Flame", "Rod")), count = add(Setting.num("Count", 10, 1, 40));
    public HitParticles(){ super("Hit Particles", Cat.VISUALS); }
    public void spawn(Entity e){
      if (mc.world == null) return; var pe = switch (style.mode) { case 1 -> net.minecraft.particle.ParticleTypes.ENCHANTED_HIT; case 2 -> net.minecraft.particle.ParticleTypes.HEART;
        case 3 -> net.minecraft.particle.ParticleTypes.FLAME; case 4 -> net.minecraft.particle.ParticleTypes.END_ROD; default -> net.minecraft.particle.ParticleTypes.CRIT; };
      var r = java.util.concurrent.ThreadLocalRandom.current();
      for (int i = 0; i < (int) count.n; i++) mc.world.addParticle(pe, e.getX() + (r.nextDouble() - 0.5) * e.getWidth(), e.getY() + r.nextDouble() * e.getHeight(), e.getZ() + (r.nextDouble() - 0.5) * e.getWidth(), (r.nextDouble() - 0.5) * 0.4, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
    }
  }
  public static class HitWaves extends Module {
    final Setting color = add(Setting.color("Color", 0.78)), rainbow = add(Setting.bool("Rainbow", false)), speed = add(Setting.num("Speed", 1, 0.3, 3)), size = add(Setting.num("Size", 1.6, 0.5, 3)), thick = add(Setting.num("Thickness", 0.06, 0.02, 0.3));
    final List<double[]> list = new ArrayList<>();
    public HitWaves(){ super("Hit Waves", Cat.VISUALS); }
    public void spawn(Entity e){ list.add(new double[]{ e.getX(), e.getY() + 0.05, e.getZ(), System.nanoTime() }); }
    @Override public void world(WorldRenderContext c, float td){
      long now = System.nanoTime(); list.removeIf(k -> (now - k[3]) / 1e9 > 0.8 / speed.n); if (list.isEmpty()) return;
      Matrix4f m = RenderUtil.view(c); RenderUtil.begin(true);
      for (double[] k : list) { double t = (now - k[3]) / 1e9 * speed.n / 0.8; RenderUtil.ring(m, k[0], k[1], k[2], 0.2 + size.n * ease(t, 0.5), thick.n, 40, argb(t < 0.5 ? 1 : (1 - t) * 2, col(color, rainbow, t))); }
      RenderUtil.end();
    }
  }
}
