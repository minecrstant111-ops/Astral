package dev.astral;
import com.google.gson.*;
import java.nio.file.*;
import net.fabricmc.loader.api.FabricLoader;
public class Config {
  static final Gson G = new GsonBuilder().setPrettyPrinting().create();
  static Path file(){ return FabricLoader.getInstance().getConfigDir().resolve("astral.json"); }
  public static void save(){
    try {
      JsonObject root = new JsonObject();
      for (Module m : Astral.MODULES) {
        JsonObject o = new JsonObject(); o.addProperty("on", m.on); o.addProperty("x", m.x); o.addProperty("y", m.y);
        for (Setting s : m.settings) switch (s.type) {
          case BOOL -> o.addProperty(s.name, s.b);
          case NUM, COLOR -> o.addProperty(s.name, s.n);
          case MODE -> o.addProperty(s.name, s.mode);
          case TEXT -> o.addProperty(s.name, s.text);
        }
        root.add(m.name, o);
      }
      Files.writeString(file(), G.toJson(root));
    } catch (Exception e) { e.printStackTrace(); }
  }
  public static void load(){
    try {
      if (!Files.exists(file())) return;
      JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
      for (Module m : Astral.MODULES) {
        if (!root.has(m.name)) continue; JsonObject o = root.getAsJsonObject(m.name);
        if (o.has("on")) m.on = o.get("on").getAsBoolean();
        if (o.has("x")) m.x = o.get("x").getAsInt(); if (o.has("y")) m.y = o.get("y").getAsInt();
        for (Setting s : m.settings) { if (!o.has(s.name)) continue; JsonElement e = o.get(s.name);
          switch (s.type) { case BOOL -> s.b = e.getAsBoolean(); case NUM, COLOR -> s.n = e.getAsDouble();
            case MODE -> s.mode = Math.min(e.getAsInt(), s.modes.length - 1); case TEXT -> s.text = e.getAsString(); } }
      }
    } catch (Exception e) { e.printStackTrace(); }
  }
}
