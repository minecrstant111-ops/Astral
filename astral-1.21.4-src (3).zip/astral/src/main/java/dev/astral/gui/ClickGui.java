package dev.astral.gui;
import java.util.*;
import java.util.function.*;
import dev.astral.Astral;
import dev.astral.Config;
import dev.astral.Module;
import dev.astral.RenderUtil;
import dev.astral.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class ClickGui extends Screen {
  static final int PW = 140, RH = 17, ACC = 0xFF8B5CF6, ACC2 = 0xFFC084FC, TXT = 0xFFC9C3E0, ON = 0xFF6D28D9;
  static final class Hit { final int x, y, w, h; final IntConsumer click; final DoubleConsumer drag;
    Hit(int x, int y, int w, int h, IntConsumer c, DoubleConsumer d){ this.x = x; this.y = y; this.w = w; this.h = h; click = c; drag = d; }
    boolean in(double mx, double my){ return mx >= x && mx < x + w && my >= y && my < y + h; } }
  final List<Hit> hits = new ArrayList<>(); Hit active; Module dragMod; Setting typing;
  final float[] scroll = new float[3], maxScroll = new float[3]; final int[] px = new int[3]; final boolean[] shown = new boolean[3];
  int visTop, visBot, sel = 0, dragOffX, dragOffY; boolean edit; double lastMx, lastMy;

  public ClickGui(){ super(Text.literal("Astral Visuals")); }
  @Override public boolean shouldPause(){ return false; }
  @Override public void removed(){ Config.save(); }
  void hit(int x, int y, int w, int h, IntConsumer c, DoubleConsumer d){ if (y + h > visTop && y < visBot) hits.add(new Hit(x, y, w, h, c, d)); }

  void background(DrawContext c, long ms){
    int n = 40;
    for (int i = 0; i < n; i++) {
      double k = 0.5 + 0.5 * Math.sin(ms / 1400.0 - i * 0.28); k = k * k * (0.45 + 0.55 * (1 - 0.4 * i / n));
      c.fill(0, height * i / n, width, height * (i + 1) / n, RenderUtil.lerpColor(0xFF05030A, 0xFF7C2BE0, k));
    }
  }
  void title(DrawContext c, long ms){
    String t = "Astral Visuals"; float sc = 2f; int tw = 0; for (char ch : t.toCharArray()) tw += RenderUtil.tw(String.valueOf(ch));
    var st = c.getMatrices(); st.push(); st.translate(width / 2f - tw * sc / 2f, 8, 0); st.scale(sc, sc, 1f); int x = 0;
    for (int i = 0; i < t.length(); i++) { String s = String.valueOf(t.charAt(i)); double k = 0.5 + 0.5 * Math.sin(ms / 500.0 - i * 0.5);
      RenderUtil.text(c, s, x, 0, RenderUtil.lerpColor(0xFFB794F6, 0xFFF0ABFC, k), true); x += RenderUtil.tw(s); }
    st.pop();
  }

  @Override public void render(DrawContext c, int mx, int my, float td){
    long ms = System.currentTimeMillis(); background(c, ms); title(c, ms);
    hits.clear(); visTop = 0; visBot = height;
    for (Module m : Astral.MODULES) if (m.on && m.movable && m.x >= 0) {
      c.drawBorder(m.x - 2, m.y - 2, m.w + 4, m.h + 4, edit ? 0xFFC084FC : 0x888B5CF6);
      final Module mm = m; hit(m.x - 2, m.y - 2, m.w + 4, m.h + 4, b -> { dragMod = mm; dragOffX = (int) lastMx - mm.x; dragOffY = (int) lastMy - mm.y; }, null);
    }
    String[] names = { "Visuals", "Hud", "Utility", "Edit HUD" }; int total = 0; for (String s : names) total += RenderUtil.tw(s) + 18 + 6; total -= 6;
    int tx = (width - total) / 2, ty = 40;
    for (int i = 0; i < 4; i++) { int bw = RenderUtil.tw(names[i]) + 18; boolean act = i == 3 ? edit : (!edit && i == sel);
      RenderUtil.rrect(c, tx, ty, bw, 16, 8, act ? ACC : 0xB01A1230); RenderUtil.text(c, names[i], tx + 9, ty + 4, act ? 0xFFFFFFFF : TXT, false);
      final int ii = i; hit(tx, ty, bw, 16, b -> { if (ii == 3) edit = !edit; else { sel = ii; edit = false; } }, null); tx += bw + 6; }
    Arrays.fill(shown, false);
    if (edit) { String h = "Drag HUD elements with your finger / mouse"; RenderUtil.text(c, h, (width - RenderUtil.tw(h)) / 2, 64, 0xFFE9D5FF, true); return; }
    Module.Cat[] cats = Module.Cat.values(); int fit = MathHelper.clamp((width - 12) / (PW + 12), 1, 3), first = MathHelper.clamp(sel, 0, 3 - fit);
    int x0 = (width - (fit * PW + (fit - 1) * 12)) / 2;
    for (int k = 0; k < fit; k++) { int idx = first + k; px[idx] = x0 + k * (PW + 12); shown[idx] = true; panel(c, cats[idx], px[idx], 64, mx, my, idx); }
  }

  void panel(DrawContext c, Module.Cat cat, int pxx, int py, int mx, int my, int idx){
    int ph = Math.max(60, height - py - 10);
    RenderUtil.rrect(c, pxx, py, PW, ph, 7, 0xE0100C1C); RenderUtil.rrect(c, pxx, py, PW, 20, 7, 0xFF2B1B5E);
    RenderUtil.text(c, cat.label, pxx + 8, py + 6, 0xFFFFFFFF, false);
    int top = py + 22; visTop = top; visBot = py + ph - 2; c.enableScissor(pxx, top, pxx + PW, visBot);
    int y = top + (int) scroll[idx];
    for (Module m : Astral.MODULES) {
      if (m.cat != cat) continue;
      boolean hov = mx >= pxx + 3 && mx < pxx + PW - 3 && my >= y && my < y + RH - 1 && my >= top && my < visBot;
      RenderUtil.rrect(c, pxx + 3, y, PW - 6, RH - 1, 4, m.on ? ON : hov ? 0xFF2A2340 : 0xFF1A1630);
      RenderUtil.text(c, m.name, pxx + 8, y + 4, m.on ? 0xFFFFFFFF : TXT, false);
      if (!m.settings.isEmpty()) RenderUtil.text(c, m.open ? "v" : ">", pxx + PW - 14, y + 4, 0xFFA79EC8, false);
      final Module mm = m; hit(pxx + 3, y, PW - 6, RH - 1, b -> { if (b == 0) mm.toggle(); else if (b == 1) mm.open = !mm.open; }, null);
      y += RH;
      if (m.open) for (Setting s : m.settings) y += setting(c, s, pxx + 7, y, PW - 14);
    }
    maxScroll[idx] = Math.max(0, (y - (int) scroll[idx]) - top - (ph - 26));
    c.disableScissor();
  }

  static String fmt(double v){ return v == Math.rint(v) ? String.valueOf((int) v) : String.format("%.2f", v); }

  int setting(DrawContext c, Setting s, int x, int y, int w){
    if (s.type == Setting.T.BOOL) {
      RenderUtil.text(c, s.name, x + 2, y + 3, TXT, false); int tx = x + w - 22;
      RenderUtil.rrect(c, tx, y + 2, 20, 10, 5, s.b ? ACC : 0xFF2B2B42); RenderUtil.rrect(c, tx + (s.b ? 11 : 1), y + 3, 8, 8, 4, 0xFFFFFFFF);
      hit(x, y, w, 14, b -> s.b = !s.b, null); return 15;
    } else if (s.type == Setting.T.NUM) {
      RenderUtil.text(c, s.name, x + 2, y + 1, TXT, false); String v = fmt(s.n); RenderUtil.text(c, v, x + w - 2 - RenderUtil.tw(v), y + 1, 0xFFFFFFFF, false);
      RenderUtil.rrect(c, x + 2, y + 12, w - 4, 4, 2, 0xFF2B2B42); int fw = (int) ((s.n - s.min) / (s.max - s.min) * (w - 4)); RenderUtil.rrect(c, x + 2, y + 12, Math.max(fw, 4), 4, 2, ACC2);
      final int bx = x + 2, bw = w - 4;
      hit(x, y, w, 20, null, mxx -> { double p = MathHelper.clamp((mxx - bx) / bw, 0, 1); s.n = Math.round((s.min + p * (s.max - s.min)) * 100) / 100.0; }); return 21;
    } else if (s.type == Setting.T.MODE) {
      RenderUtil.text(c, s.name, x + 2, y + 3, TXT, false); String v = "< " + s.modeName() + " >"; RenderUtil.text(c, v, x + w - 2 - RenderUtil.tw(v), y + 3, 0xFFFFFFFF, false);
      hit(x, y, w, 14, b -> s.mode = Math.floorMod(s.mode + (b == 0 ? 1 : -1), s.modes.length), null); return 15;
    } else if (s.type == Setting.T.COLOR) {
      RenderUtil.text(c, s.name, x + 2, y + 1, TXT, false); int sw = w - 4;
      for (int i = 0; i < sw; i += 2) c.fill(x + 2 + i, y + 12, x + 4 + i, y + 17, 0xFF000000 | Setting.hsv(i / (float) sw, 1f, 1f));
      int mk = x + 2 + (int) (s.n * sw); c.fill(mk - 1, y + 10, mk + 1, y + 19, 0xFFFFFFFF); final int bx = x + 2;
      hit(x, y, w, 20, null, mxx -> s.n = MathHelper.clamp((mxx - bx) / sw, 0, 1)); return 21;
    } else {
      RenderUtil.text(c, s.name, x + 2, y + 1, TXT, false); boolean ty = typing == s;
      RenderUtil.rrect(c, x + 2, y + 11, w - 4, 12, 3, ty ? 0xFF2F2A55 : 0xFF1F1B33); RenderUtil.text(c, s.text + (ty && System.currentTimeMillis() / 400 % 2 == 0 ? "_" : ""), x + 5, y + 13, 0xFFFFFFFF, false);
      hit(x, y, w, 24, b -> typing = s, null); return 25;
    }
  }

  @Override public boolean mouseClicked(double mx, double my, int button){
    typing = null; lastMx = mx; lastMy = my;
    for (int i = hits.size() - 1; i >= 0; i--) { Hit h = hits.get(i); if (h.in(mx, my)) {
      if (h.click != null) h.click.accept(button); if (h.drag != null) { h.drag.accept(mx); active = h; } return true; } }
    return super.mouseClicked(mx, my, button);
  }
  @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy){
    if (active != null && active.drag != null) { active.drag.accept(mx); return true; }
    if (dragMod != null) { dragMod.x = MathHelper.clamp((int) mx - dragOffX, 0, Math.max(0, width - dragMod.w)); dragMod.y = MathHelper.clamp((int) my - dragOffY, 0, Math.max(0, height - dragMod.h)); return true; }
    return false;
  }
  @Override public boolean mouseReleased(double mx, double my, int b){ active = null; dragMod = null; return super.mouseReleased(mx, my, b); }
  @Override public boolean mouseScrolled(double mx, double my, double hx, double vy){
    for (int i = 0; i < 3; i++) if (shown[i] && mx >= px[i] && mx < px[i] + PW) { scroll[i] = MathHelper.clamp(scroll[i] + (float) vy * 16, -maxScroll[i], 0); return true; }
    return false;
  }
  @Override public boolean keyPressed(int key, int sc, int mod){
    if (typing != null) { if (key == GLFW.GLFW_KEY_BACKSPACE && !typing.text.isEmpty()) typing.text = typing.text.substring(0, typing.text.length() - 1);
      else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_ESCAPE) typing = null; return true; }
    if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
    return super.keyPressed(key, sc, mod);
  }
  @Override public boolean charTyped(char ch, int mod){ if (typing != null && typing.text.length() < 16 && ch >= 32) { typing.text += ch; return true; } return false; }
}
