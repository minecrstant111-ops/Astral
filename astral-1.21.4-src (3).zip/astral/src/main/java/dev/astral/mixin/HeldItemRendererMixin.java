package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
  @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
  private void astral$in(AbstractClientPlayerEntity p, float td, float pitch, Hand hand, float swing, ItemStack item, float equip, MatrixStack m, VertexConsumerProvider vc, int light, CallbackInfo ci){
    Mods.ViewModel v = Astral.get(Mods.ViewModel.class); m.push();
    if (v != null && v.on) { m.translate(v.px.n, v.py.n, v.pz.n); float s = (float) v.scale.n; m.scale(s, s, s); }
  }
  @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
  private void astral$out(AbstractClientPlayerEntity p, float td, float pitch, Hand hand, float swing, ItemStack item, float equip, MatrixStack m, VertexConsumerProvider vc, int light, CallbackInfo ci){ m.pop(); }
}
