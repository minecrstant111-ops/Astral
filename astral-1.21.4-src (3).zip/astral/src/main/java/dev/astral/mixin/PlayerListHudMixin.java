package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.scoreboard.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {
  @Inject(method = "render", at = @At("HEAD"))
  private void astral$in(DrawContext c, int w, Scoreboard sb, ScoreboardObjective o, CallbackInfo ci){
    Mods.TAnimations t = Astral.get(Mods.TAnimations.class); c.getMatrices().push();
    if (t != null && t.on) c.getMatrices().translate(0, t.tabOffset(), 0);
  }
  @Inject(method = "render", at = @At("RETURN"))
  private void astral$out(DrawContext c, int w, Scoreboard sb, ScoreboardObjective o, CallbackInfo ci){ c.getMatrices().pop(); }
}
