package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
  @Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"), cancellable = true)
  private void astral$flat(ItemEntityRenderState s, MatrixStack m, VertexConsumerProvider v, int light, CallbackInfo ci){
    if (!Astral.on(Mods.ItemPhysic.class) || s.itemRenderState.isEmpty()) return;
    m.push(); m.translate(0, 0.03, 0); m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90)); m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s.uniqueOffset * 57.3f));
    s.itemRenderState.render(m, v, light, OverlayTexture.DEFAULT_UV); m.pop(); ci.cancel();
  }
}
