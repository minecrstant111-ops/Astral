package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.text.TextVisitFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(TextVisitFactory.class)
public class TextVisitFactoryMixin {
  @ModifyVariable(method = "visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z", at = @At("HEAD"), argsOnly = true)
  private static String astral$name(String text){
    Mods.NameChanger n = Astral.get(Mods.NameChanger.class); return n != null && n.on ? n.replace(text) : text;
  }
}
