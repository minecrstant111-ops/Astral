package dev.astral.mixin;
import dev.astral.HudMods;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
  @Inject(method = "doAttack", at = @At("HEAD")) private void astral$l(CallbackInfoReturnable<Boolean> cir){ HudMods.Cps.left(); }
  @Inject(method = "doItemUse", at = @At("HEAD")) private void astral$r(CallbackInfo ci){ HudMods.Cps.right(); }
}
