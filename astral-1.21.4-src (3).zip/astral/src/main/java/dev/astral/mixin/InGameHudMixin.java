package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public class InGameHudMixin {
  @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
  private void astral$cross(DrawContext ctx, RenderTickCounter tc, CallbackInfo ci){
    Mods.Crosshair c = Astral.get(Mods.Crosshair.class); MinecraftClient mc = MinecraftClient.getInstance();
    if (c != null && c.on && mc.player != null && mc.options.getPerspective().isFirstPerson()) { c.draw(ctx); ci.cancel(); }
  }
}
