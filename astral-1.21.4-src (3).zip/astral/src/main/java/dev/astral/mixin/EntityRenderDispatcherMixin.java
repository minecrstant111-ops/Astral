package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
  @Inject(method = "renderHitbox", at = @At("HEAD"), cancellable = true)
  private static void astral$hitbox(MatrixStack m, VertexConsumer vc, Entity e, float td, float r, float g, float b, CallbackInfo ci){
    Mods.HitboxCustomizer h = Astral.get(Mods.HitboxCustomizer.class); if (h == null || !h.on) return;
    float[] c = h.rgb(); Box box = e.getBoundingBox().offset(-e.getX(), -e.getY(), -e.getZ()); VertexRendering.drawBox(m, vc, box, c[0], c[1], c[2], 1f);
    if (h.eye.b) VertexRendering.drawBox(m, vc, box.minX, e.getStandingEyeHeight() - 0.01, box.minZ, box.maxX, e.getStandingEyeHeight() + 0.01, box.maxZ, 1f, 0f, 0f, 1f);
    ci.cancel();
  }
}
