package dev.astral.mixin;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor { @Mutable @Accessor("value") void astral$setValue(Object v); }
