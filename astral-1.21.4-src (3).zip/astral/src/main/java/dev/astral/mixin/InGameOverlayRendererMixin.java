package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
  @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
  private static void astral$fire(CallbackInfo ci){ Mods.NoOverlay n = Astral.get(Mods.NoOverlay.class); if (n.on && n.fire.b) ci.cancel(); }
  @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true)
  private static void astral$water(CallbackInfo ci){ Mods.NoOverlay n = Astral.get(Mods.NoOverlay.class); if (n.on && n.water.b) ci.cancel(); }
  @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true)
  private static void astral$wall(CallbackInfo ci){ Mods.NoOverlay n = Astral.get(Mods.NoOverlay.class); if (n.on && n.wall.b) ci.cancel(); }
}
