package dev.astral.mixin;
import dev.astral.*;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
  @Shadow public abstract float getFarPlaneDistance();
  @Inject(method = "getBasicProjectionMatrix", at = @At("HEAD"), cancellable = true)
  private void astral$proj(float fov, CallbackInfoReturnable<Matrix4f> cir){
    Mods.AspectRatio a = Astral.get(Mods.AspectRatio.class); if (a == null || !a.on) return; double r = a.ratio(); if (r <= 0) return;
    cir.setReturnValue(new Matrix4f().perspective(fov * 0.017453292F, (float) r, 0.05F, getFarPlaneDistance()));
  }
  @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
  private void astral$hurt(MatrixStack m, float t, CallbackInfo ci){ if (Astral.on(Mods.NoHurtCam.class)) ci.cancel(); }
}
