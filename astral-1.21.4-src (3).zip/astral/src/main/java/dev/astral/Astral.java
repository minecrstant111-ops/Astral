package dev.astral;
import java.util.*;
import dev.astral.gui.ClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
public class Astral implements ClientModInitializer {
  public static final List<Module> MODULES = new ArrayList<>();
  static final Map<Class<?>, Module> BY = new HashMap<>();
  public static KeyBinding guiKey, zoomKey; public static LivingEntity target; public static long targetTime;
  public static int combo; public static long lastHit; static boolean booted;
  static void reg(Module m){ MODULES.add(m); BY.put(m.getClass(), m); }
  @SuppressWarnings("unchecked") public static <T extends Module> T get(Class<T> c){ return (T) BY.get(c); }
  public static boolean on(Class<? extends Module> c){ Module m = BY.get(c); return m != null && m.on; }
  @Override public void onInitializeClient(){
    reg(new Mods.AspectRatio()); reg(new Mods.TAnimations()); reg(new Mods.BlockOverlay()); reg(new Mods.ChinaHat());
    reg(new Mods.Crosshair()); reg(new Mods.Fullbright()); reg(new Mods.NoOverlay()); reg(new Mods.NoHurtCam());
    reg(new Mods.HitColor()); reg(new Mods.ItemPhysic()); reg(new Mods.HitboxCustomizer()); reg(new Mods.JumpCircles());
    reg(new Mods.Nimb()); reg(new Mods.TargetESP()); reg(new Mods.Trails()); reg(new Mods.ViewModel());
    reg(new Mods.Trajectory()); reg(new Mods.NameChanger());
    reg(new Mods.Zoom()); reg(new Mods.TimeChanger()); reg(new Mods.Weather()); reg(new Mods.HitParticles()); reg(new Mods.HitWaves());
    reg(new HudMods.ArmorHud()); reg(new HudMods.CooldownsHud()); reg(new HudMods.HitCounter()); reg(new HudMods.Hud()); reg(new HudMods.Cps());
    reg(new HudMods.Keystrokes()); reg(new HudMods.PotionHud()); reg(new HudMods.SpeedHud()); reg(new HudMods.DirectionHud());
    reg(new UtilMods.AutoSprint()); reg(new UtilMods.AutoRespawn()); reg(new UtilMods.ItemScroller()); reg(new UtilMods.ToggleSneak());
    Config.load();
    guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.astral.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.misc"));
    zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.astral.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.misc"));
    ClientTickEvents.END_CLIENT_TICK.register(mc -> {
      if (!booted && mc.options != null) { booted = true; for (Module m : MODULES) if (m.on) m.onEnable(); }
      while (guiKey.wasPressed()) mc.setScreen(new ClickGui());
      for (Module m : MODULES) if (m.on) m.tick();
    });
    HudRenderCallback.EVENT.register((ctx, tc) -> { float td = tc.getTickDelta(true); for (Module m : MODULES) if (m.on) m.hud(ctx, td); });
    WorldRenderEvents.LAST.register(ctx -> { float td = ctx.tickCounter().getTickDelta(true); for (Module m : MODULES) if (m.on) m.world(ctx, td); });
    WorldRenderEvents.BLOCK_OUTLINE.register((wrc, boc) -> !on(Mods.BlockOverlay.class));
    AttackEntityCallback.EVENT.register((p, w, hand, e, hit) -> {
      if (w.isClient && e instanceof LivingEntity le) { target = le; targetTime = System.currentTimeMillis(); combo++; lastHit = targetTime;
        Mods.HitParticles hp = get(Mods.HitParticles.class); if (hp != null && hp.on) hp.spawn(le);
        Mods.HitWaves hw = get(Mods.HitWaves.class); if (hw != null && hw.on) hw.spawn(le); }
      return ActionResult.PASS; });
    ScreenEvents.AFTER_INIT.register((c, screen, sw, sh) -> {
      if (screen instanceof HandledScreen<?> hs) ScreenEvents.afterTick(screen).register(s -> UtilMods.ItemScroller.scroll(hs)); });
    ClientLifecycleEvents.CLIENT_STOPPING.register(c -> { Config.save(); for (Module m : MODULES) if (m.on) m.onDisable(); });
  }
}
