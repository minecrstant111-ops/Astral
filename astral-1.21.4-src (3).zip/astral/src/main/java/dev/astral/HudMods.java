package dev.astral;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import dev.astral.gui.ClickGui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.*;
import net.minecraft.util.math.MathHelper;

public final class HudMods {
  private HudMods(){}
  static final int BG = 0xD014101F, ACC = 0xFF8B5CF6, WHITE = 0xFFFFFFFF, GRAY = 0xFF9A93B8;
  static boolean gui(){ return Module.mc.currentScreen instanceof ClickGui; }

  public static class Hud extends Module {
    final Setting fps = add(Setting.bool("FPS", true)), ping = add(Setting.bool("Ping", true)), time = add(Setting.bool("Time", true)), coords = add(Setting.bool("Coords", false));
    static final DateTimeFormatter F = DateTimeFormatter.ofPattern("HH:mm");
    public Hud(){ super("HUD", Cat.HUD); at(6, 6); on = true; }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<String> parts = new ArrayList<>();
      if (fps.b) parts.add(mc.getCurrentFps() + " fps");
      if (ping.b) { PlayerListEntry e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()); parts.add((e == null ? 0 : e.getLatency()) + " ms"); }
      if (time.b) parts.add(LocalTime.now().format(F));
      if (coords.b) parts.add((int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ());
      int tw = RenderUtil.tw("Astral"); for (String p : parts) tw += RenderUtil.tw(" | ") + RenderUtil.tw(p);
      w = tw + 14; h = 18; RenderUtil.rrect(c, x, y, w, h, 5, BG);
      int cx = x + 7, cy = y + 5; RenderUtil.text(c, "Astral", cx, cy, ACC, false); cx += RenderUtil.tw("Astral");
      for (String p : parts) { RenderUtil.text(c, " | ", cx, cy, 0xFF55556A, false); cx += RenderUtil.tw(" | "); RenderUtil.text(c, p, cx, cy, WHITE, false); cx += RenderUtil.tw(p); }
    }
  }

  public static class ArmorHud extends Module {
    static final EquipmentSlot[] S = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    public ArmorHud(){ super("Armor HUD", Cat.HUD); at(-1, -1); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return;
      if (x < 0) { x = c.getScaledWindowWidth() / 2 + 98; y = c.getScaledWindowHeight() - 40; }
      w = 84; h = 34; RenderUtil.rrect(c, x, y, w, h, 5, BG);
      for (int i = 0; i < 4; i++) {
        ItemStack s = mc.player.getEquippedStack(S[i]); int ix = x + 3 + i * 20; if (s.isEmpty()) continue;
        c.drawItem(s, ix, y + 3);
        if (s.isDamageable()) { int pct = 100 - s.getDamage() * 100 / s.getMaxDamage(); String t = pct + "%"; int col = 0xFF000000 | Setting.hsv(pct / 300f, 1f, 1f);
          c.getMatrices().push(); c.getMatrices().translate(ix + 8 - RenderUtil.tw(t) * 0.3f, y + 22, 0); c.getMatrices().scale(0.6f, 0.6f, 1); RenderUtil.text(c, t, 0, 0, col, true); c.getMatrices().pop(); }
      }
    }
  }

  public static class CooldownsHud extends Module {
    static final Item[] ITEMS = { Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.SHIELD, Items.WIND_CHARGE, Items.TRIDENT, Items.CROSSBOW, Items.FIREWORK_ROCKET, Items.SNOWBALL };
    public CooldownsHud(){ super("Cooldowns HUD", Cat.HUD); at(6, 70); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<Object[]> rows = new ArrayList<>();
      for (Item it : ITEMS) { ItemStack st = new ItemStack(it); float p = mc.player.getItemCooldownManager().getCooldownProgress(st, td); if (p > 0) rows.add(new Object[]{ st, p }); }
      if (rows.isEmpty() && gui()) rows.add(new Object[]{ new ItemStack(Items.ENDER_PEARL), 0.65f });
      w = 100; h = rows.isEmpty() ? 14 : rows.size() * 19 + 3; if (rows.isEmpty()) return;
      RenderUtil.rrect(c, x, y, w, h, 5, BG); int yy = y + 3;
      for (Object[] r : rows) { float p = (float) r[1]; c.drawItem((ItemStack) r[0], x + 3, yy);
        RenderUtil.rrect(c, x + 24, yy + 10, 46, 4, 2, 0xFF2B2B42); RenderUtil.rrect(c, x + 24, yy + 10, Math.max(4, (int) (46 * (1 - p))), 4, 2, ACC);
        RenderUtil.text(c, (int) (p * 100) + "%", x + 74, yy + 5, WHITE, false); yy += 19; }
    }
  }

  public static class HitCounter extends Module {
    int prevHurt;
    public HitCounter(){ super("Hit Counter", Cat.HUD); at(6, 40); }
    @Override public void tick(){ if (mc.player == null) return; int hu = mc.player.hurtTime; if (hu > prevHurt || System.currentTimeMillis() - Astral.lastHit > 3500) Astral.combo = 0; prevHurt = hu; }
    @Override public void hud(DrawContext c, float td){
      String t = "Combo: " + Astral.combo; w = RenderUtil.tw(t) + 14; h = 18;
      RenderUtil.rrect(c, x, y, w, h, 5, BG); RenderUtil.text(c, "Combo:", x + 7, y + 5, GRAY, false); RenderUtil.text(c, "" + Astral.combo, x + 7 + RenderUtil.tw("Combo: "), y + 5, ACC, false);
    }
  }

  public static class Cps extends Module {
    static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
    final Setting right = add(Setting.bool("Right click", false));
    public Cps(){ super("CPS", Cat.HUD); at(6, 28); }
    public static void left(){ L.add(System.currentTimeMillis()); } public static void right(){ R.add(System.currentTimeMillis()); }
    static int count(ArrayDeque<Long> q){ long n = System.currentTimeMillis(); while (!q.isEmpty() && n - q.peekFirst() > 1000) q.pollFirst(); return q.size(); }
    @Override public void hud(DrawContext c, float td){
      String t = count(L) + (right.b ? " | " + count(R) : "") + " CPS"; w = RenderUtil.tw(t); h = 9; RenderUtil.text(c, t, x, y, WHITE, true);
    }
  }

  // ---- Keystrokes ----
  public static class Keystrokes extends Module {
    public Keystrokes(){ super("Keystrokes", Cat.HUD); at(6, 130); }
    void key(DrawContext c, int kx, int ky, int kw, int kh, String s, boolean down){
      RenderUtil.rrect(c, kx, ky, kw, kh, 4, down ? 0xE08B5CF6 : BG); RenderUtil.text(c, s, kx + (kw - RenderUtil.tw(s)) / 2, ky + (kh - 8) / 2, down ? WHITE : GRAY, false);
    }
    @Override public void hud(DrawContext c, float td){
      var o = mc.options; w = 64; h = 64;
      key(c, x + 22, y, 20, 20, "W", o.forwardKey.isPressed()); key(c, x, y + 22, 20, 20, "A", o.leftKey.isPressed());
      key(c, x + 22, y + 22, 20, 20, "S", o.backKey.isPressed()); key(c, x + 44, y + 22, 20, 20, "D", o.rightKey.isPressed());
      key(c, x, y + 44, 31, 20, "LMB", o.attackKey.isPressed()); key(c, x + 33, y + 44, 31, 20, "RMB", o.useKey.isPressed());
    }
  }

  // ---- Potion HUD ----
  public static class PotionHud extends Module {
    public PotionHud(){ super("Potion HUD", Cat.HUD); at(6, 200); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; List<String[]> rows = new ArrayList<>(); List<Boolean> good = new ArrayList<>();
      for (StatusEffectInstance e : mc.player.getStatusEffects()) {
        int sec = e.getDuration() / 20; String time = e.isInfinite() ? "inf" : sec / 60 + ":" + String.format("%02d", sec % 60);
        rows.add(new String[]{ e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1), time }); good.add(e.getEffectType().value().isBeneficial());
      }
      if (rows.isEmpty() && gui()) { rows.add(new String[]{ "Speed 2", "0:45" }); good.add(true); }
      if (rows.isEmpty()) { w = 60; h = 14; return; }
      int mw = 0; for (String[] r : rows) mw = Math.max(mw, RenderUtil.tw(r[0]) + RenderUtil.tw(r[1]) + 18);
      w = mw; h = rows.size() * 12 + 6; RenderUtil.rrect(c, x, y, w, h, 5, BG);
      for (int i = 0; i < rows.size(); i++) { int yy = y + 4 + i * 12; RenderUtil.text(c, rows.get(i)[0], x + 6, yy, good.get(i) ? 0xFF86EFAC : 0xFFFCA5A5, false); RenderUtil.text(c, rows.get(i)[1], x + w - 6 - RenderUtil.tw(rows.get(i)[1]), yy, WHITE, false); }
    }
  }

  // ---- Speed / Direction ----
  public static class SpeedHud extends Module {
    public SpeedHud(){ super("Speed HUD", Cat.HUD); at(6, 280); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; double sp = Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ) * 20;
      String t = String.format("%.1f", sp) + " b/s"; w = RenderUtil.tw(t) + 14; h = 18; RenderUtil.rrect(c, x, y, w, h, 5, BG); RenderUtil.text(c, t, x + 7, y + 5, WHITE, false);
    }
  }
  public static class DirectionHud extends Module {
    static final String[] N = { "S", "W", "N", "E" };
    public DirectionHud(){ super("Direction HUD", Cat.HUD); at(6, 300); }
    @Override public void hud(DrawContext c, float td){
      if (mc.player == null) return; float yaw = MathHelper.wrapDegrees(mc.player.getYaw()); int f = (int) Math.floor(yaw * 4 / 360 + 0.5) & 3;
      String t = N[f] + "  " + (int) yaw; w = RenderUtil.tw(t) + 14; h = 18; RenderUtil.rrect(c, x, y, w, h, 5, BG); RenderUtil.text(c, N[f], x + 7, y + 5, ACC, false); RenderUtil.text(c, "  " + (int) yaw, x + 7 + RenderUtil.tw(N[f]), y + 5, WHITE, false);
    }
  }
}
