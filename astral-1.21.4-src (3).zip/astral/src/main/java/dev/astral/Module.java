package dev.astral;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public abstract class Module {
  public enum Cat { VISUALS("Visuals"), HUD("Hud"), UTILITY("Utility"); public final String label; Cat(String l){ label = l; } }
  protected static final MinecraftClient mc = MinecraftClient.getInstance();
  public final String name; public final Cat cat; public boolean on, open;
  public final List<Setting> settings = new ArrayList<>();
  public int x, y, w = 60, h = 14; public boolean movable;
  protected Module(String n, Cat c){ name = n; cat = c; }
  protected <S extends Setting> S add(S s){ settings.add(s); return s; }
  protected Module at(int x, int y){ this.x = x; this.y = y; movable = true; return this; }
  public void onEnable(){} public void onDisable(){} public void tick(){}
  public void hud(DrawContext c, float td){} public void world(WorldRenderContext c, float td){}
  public void toggle(){ on = !on; if (on) onEnable(); else onDisable(); }
}
