package dev.astral;
import net.minecraft.util.math.MathHelper;
public class Setting {
  public enum T { BOOL, NUM, MODE, COLOR, TEXT }
  public final String name; public final T type;
  public boolean b; public double n, min, max; public int mode; public String[] modes; public String text = "";
  private Setting(String name, T t){ this.name = name; this.type = t; }
  public static Setting bool(String n, boolean d){ Setting s = new Setting(n, T.BOOL); s.b = d; return s; }
  public static Setting num(String n, double d, double min, double max){ Setting s = new Setting(n, T.NUM); s.n = d; s.min = min; s.max = max; return s; }
  public static Setting mode(String n, int d, String... m){ Setting s = new Setting(n, T.MODE); s.mode = d; s.modes = m; return s; }
  public static Setting color(String n, double hue){ Setting s = new Setting(n, T.COLOR); s.n = hue; return s; }
  public static Setting text(String n, String d){ Setting s = new Setting(n, T.TEXT); s.text = d; return s; }
  public int rgb(){ return hsv((float) n, 1f, 1f); }
  public static int hsv(float h, float s, float v){
    h = h - (float) Math.floor(h); int i = (int) Math.floor(h * 6); float f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s), r = 0, g = 0, b = 0;
    switch (i % 6) { case 0 -> { r = v; g = t; b = p; } case 1 -> { r = q; g = v; b = p; } case 2 -> { r = p; g = v; b = t; }
      case 3 -> { r = p; g = q; b = v; } case 4 -> { r = t; g = p; b = v; } default -> { r = v; g = p; b = q; } }
    return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
  }
  public String modeName(){ return modes[mode]; }
}
