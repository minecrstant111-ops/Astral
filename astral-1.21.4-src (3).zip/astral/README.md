# Astral Visuals (Fabric 1.21.4)
Open GUI: Right Shift. Config: .minecraft/config/astral.json

Build locally (JDK 21, Gradle 8.12+):  gradle build   ->  build/libs/astral-1.0.0.jar
Or push to GitHub: Actions -> build -> download artifact "astral-jar".
Needs Fabric Loader 0.16+ and Fabric API for 1.21.4.
